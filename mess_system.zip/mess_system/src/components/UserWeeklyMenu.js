import React, { useEffect, useState } from 'react';
import { 
  Box, 
  Typography, 
  Paper, 
  CircularProgress, 
  Alert, 
  Grid,
  Card,
  CardContent,
  Chip,
  Divider,
  IconButton,
  Tooltip,
  Container,
  Avatar
} from '@mui/material';
import {
  Restaurant as RestaurantIcon,
  CalendarToday as CalendarIcon,
  AccessTime as TimeIcon,
  MonetizationOn as PriceIcon,
  Today as TodayIcon,
  CheckCircle as CheckIcon,
  Cancel as CancelIcon,
  Favorite as FavoriteIcon,
  Star as StarIcon
} from '@mui/icons-material';
import axios from 'axios';

const UserWeeklyMenu = () => {
  const [weekMenu, setWeekMenu] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchMenu = async () => {
      setLoading(true);
      setError('');
      try {
        const res = await axios.get('/api/user/menu/current-week', {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${localStorage.getItem('userToken')}`
          }
        });
        setWeekMenu(res.data.weekMenu || []);
      } catch (err) {
        setError(err.response?.data?.message || 'Failed to fetch menu');
      } finally {
        setLoading(false);
      }
    };
    fetchMenu();
  }, []);

  const getDayColor = (dayOfWeek) => {
    const colors = {
      'Monday': '#2e7d32',
      'Tuesday': '#2e7d32',
      'Wednesday': '#2e7d32',
      'Thursday': '#2e7d32',
      'Friday': '#2e7d32',
      'Saturday': '#2e7d32',
      'Sunday': '#2e7d32'
    };
    return colors[dayOfWeek] || '#2e7d32';
  };

  const getDayIcon = (dayOfWeek) => {
    const icons = {
      'Monday': '📅',
      'Tuesday': '📅',
      'Wednesday': '📅',
      'Thursday': '📅',
      'Friday': '📅',
      // 'Saturday': '📅',
      // 'Sunday': '📅'
    };
    return icons[dayOfWeek] || '📅';
  };

  const isToday = (date) => {
    const today = new Date().toDateString();
    return new Date(date).toDateString() === today;
  };
  const weeklyTotal = weekMenu.reduce((total, day) =>
    total + (day.items?.reduce((sum, item) => {
      // Extract numeric value from range (e.g., "500-1000" -> 750)
      const rangeParts = (item.range || '').split('-');
      if (rangeParts.length === 2) {
        const min = parseInt(rangeParts[0]) || 0;
        const max = parseInt(rangeParts[1]) || 0;
        return sum + Math.round((min + max) / 2);
      }
      return sum;
    }, 0) || 0),
  0);
  const weeklyMin = Math.max(0, weeklyTotal - 250);
  const weeklyMax = weeklyTotal + 250;

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="60vh">
        <CircularProgress size={60} sx={{ color: '#2e7d32' }} />
      </Box>
    );
  }

  if (error) {
    return (
      <Container maxWidth="md" sx={{ mt: 4 }}>
        <Alert severity="error" sx={{ fontSize: '1.1rem', py: 2 }}>
          {error}
        </Alert>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      {/* Header Section */}
      <Box sx={{ textAlign: 'center', mb: 6 }}>
    <Box
      sx={{
            display: 'inline-flex',
            alignItems: 'center',
            justifyContent: 'center',
            width: 80,
            height: 80,
            borderRadius: '50%',
            background: 'linear-gradient(135deg, #2e7d32, #1b5e20)',
            mb: 3,
            boxShadow: '0 8px 32px rgba(46, 125, 50, 0.3)',
          }}
        >
          <RestaurantIcon sx={{ fontSize: 40, color: 'white' }} />
        </Box>
      <Typography
          variant="h3"
        fontWeight={700}
        gutterBottom
          sx={{
            background: 'linear-gradient(135deg, #2e7d32, #1b5e20)',
            backgroundClip: 'text',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            mb: 2
          }}
        >
          This Week's Menu
        </Typography>
        <Typography variant="h6" color="text.secondary" sx={{ mb: 1 }}>
          Discover delicious meals planned for you
      </Typography>
        <Chip
          icon={<CalendarIcon />}
          label={`${weekMenu.length} Days`}
          color="success"
          variant="outlined"
          sx={{ fontWeight: 600 }}
        />
      </Box>

      {/* Menu Grid */}
      <Grid container spacing={3}>
        {weekMenu.map(({ date, dayOfWeek, items, hasMenu }, idx) => (
          <Grid item xs={12} sm={6} md={4} key={idx}>
            <Card
              elevation={8}
            sx={{
                height: '100%',
                borderRadius: 4,
                background: 'linear-gradient(135deg, #ffffff 0%, #f8fafc 100%)',
                border: isToday(date) ? `3px solid #2e7d32` : `2px solid ${getDayColor(dayOfWeek)}20`,
                transition: 'all 0.3s ease',
                position: 'relative',
                overflow: 'hidden',
                '&:hover': {
                  transform: 'translateY(-8px)',
                  boxShadow: `0 20px 40px ${getDayColor(dayOfWeek)}30`,
                  borderColor: `${getDayColor(dayOfWeek)}40`,
                },
                '&::before': {
                  content: '""',
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  right: 0,
                  height: 4,
                  background: `linear-gradient(90deg, ${getDayColor(dayOfWeek)}, ${getDayColor(dayOfWeek)}80)`,
                }
              }}
            >
              <CardContent sx={{ p: 3, height: '100%', display: 'flex', flexDirection: 'column' }}>
                {/* Day Header */}
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Typography
                    variant="h2"
                    sx={{ fontSize: '2.5rem', mr: 1, filter: 'grayscale(0.3)' }}
                  >
                    {getDayIcon(dayOfWeek)}
                  </Typography>
                  <Box sx={{ flex: 1 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Typography
                        variant="h5"
                        fontWeight={700}
                        sx={{ color: getDayColor(dayOfWeek), mb: 0.5 }}
                      >
              {dayOfWeek}
            </Typography>
                      {isToday(date) && (
                        <Chip
                          label="TODAY"
                          size="small"
                          color="success"
                          sx={{ fontWeight: 700, fontSize: '0.7rem' }}
                        />
                      )}
                    </Box>
                    <Typography variant="body2" color="text.secondary" sx={{ display: 'flex', alignItems: 'center' }}>
                      <TodayIcon sx={{ fontSize: 16, mr: 0.5 }} />
                      {new Date(date).toLocaleDateString('en-US', { 
                        month: 'short', 
                        day: 'numeric' 
                      })}
                    </Typography>
                  </Box>
                  <Chip
                    icon={hasMenu ? <CheckIcon /> : <CancelIcon />}
                    label={hasMenu ? 'Available' : 'No Menu'}
                    color={hasMenu ? 'success' : 'default'}
                    size="small"
                    variant={hasMenu ? 'filled' : 'outlined'}
                    sx={{ fontWeight: 600 }}
                  />
                </Box>

                <Divider sx={{ my: 2, opacity: 0.3 }} />

                {/* Menu Items */}
            {hasMenu ? (
                  <Box sx={{ flex: 1 }}>
                    <Typography variant="h6" fontWeight={600} sx={{ mb: 2, color: 'text.primary' }}>
                      Items:
                    </Typography>
                    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                {items.map((item, i) => (
                        <Box
                          key={i}
                          sx={{
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'center',
                            p: 1.5,
                            borderRadius: 2,
                            background: 'rgba(46, 125, 50, 0.05)',
                            border: '1px solid rgba(46, 125, 50, 0.1)',
                            transition: 'all 0.2s ease',
                            '&:hover': {
                              background: 'rgba(46, 125, 50, 0.1)',
                              transform: 'translateX(4px)',
                            }
                          }}
                        >
                          <Box sx={{ flex: 1 }}>
                            <Typography variant="body1" fontWeight={600} sx={{ color: 'text.primary' }}>
                              {item.item}
                            </Typography>
                          </Box>
                          <Chip
                            // icon={<PriceIcon />}
                            label={`${item.range}/-`}
                            size="small"
                            color="success"
                            variant="outlined"
                            sx={{ fontWeight: 600, minWidth: 80 }}
                          />
                        </Box>
                      ))}
                    </Box>
                  </Box>
                ) : (
                  <Box
                    sx={{
                      flex: 1,
                      display: 'flex',
                      flexDirection: 'column',
                      justifyContent: 'center',
                      alignItems: 'center',
                      py: 4,
                      opacity: 0.6
                    }}
                  >
                    <CancelIcon sx={{ fontSize: 48, color: 'text.secondary', mb: 2 }} />
                    <Typography variant="h6" color="text.secondary" sx={{ textAlign: 'center' }}>
                      No Menu Available
                    </Typography>
                    <Typography variant="body2" color="text.secondary" sx={{ textAlign: 'center', mt: 1 }}>
                      Check back later for updates
                    </Typography>
                  </Box>
                )}

                {/* Footer Stats */}
                {hasMenu && (
                  <Box sx={{ mt: 3, pt: 2, borderTop: '1px solid rgba(0,0,0,0.1)' }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Typography variant="body2" color="text.secondary">
                        {items.length} items
                      </Typography>
                      <Typography variant="body2" fontWeight={600} color="success.main">
                        Total: Rs {items.reduce((sum, item) => {
                          // Extract numeric value from range (e.g., "500-1000" -> 750)
                          const rangeParts = (item.range || '').split('-');
                          if (rangeParts.length === 2) {
                            const min = parseInt(rangeParts[0]) || 0;
                            const max = parseInt(rangeParts[1]) || 0;
                            return sum + Math.round((min + max) / 2);
                          }
                          return sum;
                        }, 0)}
                      </Typography>
                    </Box>
                  </Box>
                )}
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Summary Section */}
      <Box sx={{ mt: 6, p: 4, borderRadius: 4, background: 'linear-gradient(135deg, #f8fafc 0%, #e8f5e8 100%)' }}>
        <Typography variant="h5" fontWeight={600} sx={{ mb: 3, color: '#2e7d32' }}>
          Weekly Summary
        </Typography>
        <Grid container spacing={3}>
          <Grid item xs={12} sm={4}>
            <Box sx={{ textAlign: 'center', p: 2 }}>
              <Typography variant="h4" fontWeight={700} color="success.main">
                {weekMenu.filter(day => day.hasMenu).length}
              </Typography>
              <Typography variant="body1" color="text.secondary">
                Days with Menu
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={12} sm={4}>
            <Box sx={{ textAlign: 'center', p: 2 }}>
              <Typography variant="h4" fontWeight={700} color="success.main">
                {weekMenu.reduce((total, day) => total + (day.items?.length || 0), 0)}
              </Typography>
              <Typography variant="body1" color="text.secondary">
                Total Items
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={12} sm={4}>
            <Box sx={{ textAlign: 'center', p: 2 }}>
              <Typography variant="h4" fontWeight={700} color="success.main">
                Est. {weeklyMin}-{weeklyMax}/-
              </Typography>
              {/* <Typography variant="h4" fontWeight={700} color="success.main">
                Est Rs {weekMenu.reduce((total, day) => 
                  total + (day.items?.reduce((sum, item) => sum + item.price, 0)+ 250 || 0) , 0
                )}
              </Typography> */}
              <Typography variant="body1" color="text.secondary">
                Total Value
              </Typography>
            </Box>
          </Grid>
        </Grid>
      </Box>

      {/* Quick Tips Section */}
      <Box sx={{ mt: 4, p: 3, borderRadius: 3, background: 'rgba(46, 125, 50, 0.05)', border: '1px solid rgba(46, 125, 50, 0.1)' }}>
        <Typography variant="h6" fontWeight={600} sx={{ mb: 2, color: '#2e7d32', display: 'flex', alignItems: 'center' }}>
          <StarIcon sx={{ mr: 1 }} />
          Pro Tips
        </Typography>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6} md={3}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <FavoriteIcon sx={{ color: '#2e7d32', fontSize: 20 }} />
              <Typography variant="body2" color="text.secondary">
                Check daily for fresh updates
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <TimeIcon sx={{ color: '#2e7d32', fontSize: 20 }} />
              <Typography variant="body2" color="text.secondary">
                Menus are updated weekly
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <PriceIcon sx={{ color: '#2e7d32', fontSize: 20 }} />
              <Typography variant="body2" color="text.secondary">
                Ranges are inclusive of all taxes
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <RestaurantIcon sx={{ color: '#2e7d32', fontSize: 20 }} />
              <Typography variant="body2" color="text.secondary">
                All meals are freshly prepared
              </Typography>
            </Box>
          </Grid>
        </Grid>
    </Box>
    </Container>
  );
};

export default UserWeeklyMenu;