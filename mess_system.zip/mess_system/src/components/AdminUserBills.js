import React, { useEffect, useState, useMemo, useRef } from 'react';
import { 
  Box, 
  Typography, 
  Paper, 
  CircularProgress, 
  Alert, 
  Stack, 
  MenuItem, 
  Select, 
  FormControl, 
  InputLabel, 
  Container, 
  Grid, 
  Chip, 
  TextField, 
  InputAdornment, 
  Button,
  IconButton,
  Tooltip
} from '@mui/material';
import axios from 'axios';
import ReceiptLongIcon from '@mui/icons-material/ReceiptLong';
import CalendarTodayIcon from '@mui/icons-material/CalendarToday';
import SearchIcon from '@mui/icons-material/Search';
import AttachMoneyIcon from '@mui/icons-material/AttachMoney';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import CancelIcon from '@mui/icons-material/Cancel';
import PersonOutlineIcon from '@mui/icons-material/PersonOutline';
import VisibilityIcon from '@mui/icons-material/Visibility';
import { AgGridReact } from 'ag-grid-react';
import { ModuleRegistry, AllCommunityModule } from 'ag-grid-community';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import UserBillDetail from './UserBillDetail';
import './Admin.css';

ModuleRegistry.registerModules([AllCommunityModule]);

const months = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

const AdminUserBills = () => {
  const today = new Date();
  const [month, setMonth] = useState(today.getMonth());
  const [year, setYear] = useState(today.getFullYear());
  const [bills, setBills] = useState([]);
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [selectedUser, setSelectedUser] = useState(null);
  const [showUserBill, setShowUserBill] = useState(false);

  const gridRef = useRef(null);

  useEffect(() => {
    const fetchBills = async () => {
      setLoading(true);
      setError('');
      try {
        const res = await axios.get(`/api/admin/bills/${month}/${year}`, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${localStorage.getItem('adminToken')}`
          }
        });
        setBills(res.data.bills || []);
        setSummary(res.data.summary || null);
      } catch (err) {
        setError(err.response?.data?.message || 'Failed to fetch bills');
      } finally {
        setLoading(false);
      }
    };
    fetchBills();
  }, [month, year]);

  const filtered = !search
    ? bills
    : bills.filter(b => (b.username || b.userId || '').toLowerCase().includes(search.toLowerCase()));

  // Calculate totals from actual bill data to ensure accuracy
  const totalUsers = summary?.totalUsers ?? filtered.length;
  const totalAmount = summary?.totalAmount ?? filtered.reduce((sum, b) => sum + (b.totalAmount || 0), 0);
  
  // Calculate accepted/denied days from dailyBreakdown for accuracy
  let totalAcceptedDays = 0;
  let totalDeniedDays = 0;
  
  filtered.forEach(bill => {
    if (bill.dailyBreakdown && Array.isArray(bill.dailyBreakdown)) {
      bill.dailyBreakdown.forEach(day => {
        if (day.choice === 'accept') {
          totalAcceptedDays += 1;
        } else if (day.choice === 'deny') {
          totalDeniedDays += 1;
        }
      });
    }
  });

  // AG Grid column definitions
  const columnDefs = useMemo(() => [
    {
      headerName: '#',
      valueGetter: params => params.node ? params.node.rowIndex + 1 : '',
      flex: 0.5,  // takes less space than others
      cellStyle: { textAlign: 'center', fontWeight: 600 },
      editable: false
    },
    {
      headerName: 'User',
      field: 'username',
      flex: 1.5,   // bigger chunk
      cellRenderer: params => (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <PersonOutlineIcon sx={{ color: '#1976d2', fontSize: 18 }} />
          <span>{params.value || params.data.userId}</span>
        </Box>
      ),
      editable: false
    },
    {
      headerName: 'Accepted Days',
      field: 'acceptedDays',
      flex: 1,
      valueGetter: params => {
        if (params.data.dailyBreakdown && Array.isArray(params.data.dailyBreakdown)) {
          return params.data.dailyBreakdown.filter(day => day.choice === 'accept').length;
        }
        return params.value || 0;
      },
      cellRenderer: params => (
        <Chip
          label={params.value || 0}
          color="success"
          variant="outlined"
          size="small"
          icon={<CheckCircleIcon />}
          sx={{ fontWeight: 600 }}
        />
      ),
      editable: false
    },
    {
      headerName: 'Denied Days',
      field: 'deniedDays',
      flex: 1,
      valueGetter: params => {
        if (params.data.dailyBreakdown && Array.isArray(params.data.dailyBreakdown)) {
          return params.data.dailyBreakdown.filter(day => day.choice === 'deny').length;
        }
        return params.value || 0;
      },
      cellRenderer: params => (
        <Chip
          label={params.value || 0}
          color="default"
          variant="outlined"
          size="small"
          icon={<CancelIcon />}
          sx={{ fontWeight: 600 }}
        />
      ),
      editable: false
    },
    {
      headerName: 'Total Amount',
      field: 'totalAmount',
      flex: 1.1,
      // type: 'numericColumn',
      valueFormatter: params => `Rs ${Number(params.value || 0).toLocaleString('en-IN')}`,
      cellStyle: {  fontWeight: 600, color: '#1976d2' },
      editable: false,
      filter: false

    },
    {
      headerName: 'Actions',
      field: 'actions',
      flex: 0.5,
      cellStyle:{ textAlign:'center'},
      cellRenderer: params => (
        <Tooltip title="View Detailed Bill"
        componentsProps={{
          tooltip: {
            sx: {
              backgroundColor: "#1976d2", // or #1b5e20 for user
              color: "#fff",
              fontSize: "13px",
            },
          },
        }}
      >
          <IconButton
            color="primary"
            size="small"
            onClick={() => handleViewBill(params.data)}
            sx={{ 
              // backgroundColor: 'rgba(25,118,210,0.1)',
              '&:hover': { backgroundColor: 'rgba(25,118,210,0.2)' }
            }}
          >
            <VisibilityIcon fontSize="small" />
          </IconButton>
        </Tooltip>
      ),
      
      editable: false,
      sortable: false,
      filter: false
    }
  ], []);
  ;

  const defaultColDef = useMemo(() => ({
    resizable: true,
    sortable: true,
    filter: true
  }), []);

  const handleViewBill = (userData) => {
    setSelectedUser({
      userId: userData.userId,
      username: userData.username || userData.userId,
      month: month, // This is the month index (0-11)
      year: year
    });
    setShowUserBill(true);
  };

  const handleCloseUserBill = () => {
    setShowUserBill(false);
    setSelectedUser(null);
  };

  return (
    <Container maxWidth="lg" sx={{ pt: 2, pb: 0 }}>
      {/* Header */}
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
        {/* <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            gap: 1,
            // justifyContent: 'center',
            // width: 80,
            // height: 80,
            // borderRadius: '50%',
            // background: 'linear-gradient(135deg, #1976d2, #1565c0)',
            // mb: 2,
            // boxShadow: '0 8px 32px rgba(25, 118, 210, 0.3)'
          }}
        >
          <ReceiptLongIcon sx={{fontSize:22,color: '#1976d2' }} />
          <Typography
          variant="subtitle1"
          fontWeight={600}
          
          sx={{
            color: '#1976d2',
          }}
        >
          All User Bills
        </Typography>
        </Box> */}
        
        <Box sx={{display: 'flex', gap: 1}}>
        
      
</Box>
      {/* Filters */}
      <Grid container spacing={1} justifyContent="center" sx={{ mt:-1 }}>
        <Grid item xs={12} md={3}>
        <FormControl
      fullWidth
      sx={{
        '& .MuiInputBase-root': { height: 32, fontSize: 12 },  // smaller input
        '& .MuiInputLabel-root': { fontSize: 12 },
        '& .MuiMenuItem-root': { fontSize: 12, py: 0.5 },
      }}
    >
            <InputLabel>Month</InputLabel>
            <Select value={month} label="Month" onChange={e => setMonth(e.target.value)}>
              {months.map((m, idx) => (
                <MenuItem key={m} value={idx}>{m}</MenuItem>
              ))}
            </Select>
          </FormControl>
        </Grid>
        <Grid item xs={12} md={2}>
        <FormControl
      fullWidth
      sx={{
        '& .MuiInputBase-root': { height: 32, fontSize: 12 },
        '& .MuiInputLabel-root': { fontSize: 12 },
        '& .MuiMenuItem-root': { fontSize: 12, py: 0.5 },
      }}
    >
            <InputLabel>Year</InputLabel>
            <Select value={year} label="Year" onChange={e => setYear(e.target.value)}>
              {[year, year - 1, year - 2].map(y => (
                <MenuItem key={y} value={y}>{y}</MenuItem>
              ))}
            </Select>
          </FormControl>
        </Grid>
        <Grid item xs={12} md={5}>
          <TextField
            label="Search by username"
            value={search}
            onChange={e => setSearch(e.target.value)}
            size="small"
            fullWidth
            sx={{
              '& .MuiInputBase-root': { height: 32, fontSize: 12 },
              '& .MuiInputLabel-root': { fontSize: 12 },
            }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon sx={{ color: '#1976d2', fontSize: 18 }} />
                </InputAdornment>
              )
            }}
          />
        </Grid>
      </Grid>
      </Box>
      

      {loading && (
        <Box display="flex" justifyContent="center" my={4}>
          <CircularProgress size={60} />
        </Box>
      )}
      
      {error && (
        <Alert severity="error" sx={{ mb: 2, borderRadius: 2, fontSize: 15 }}>
          {error}
        </Alert>
      )}

      {/* Bills Table */}
      {!loading && !error && (
        <Paper elevation={8} sx={{ borderRadius: 3, overflow: 'hidden', mt:0,mb: 1 }}>
          <Box sx={{ 
            p: 1, 
            background: 'linear-gradient(135deg, rgba(25,118,210,0.05), rgba(25,118,210,0.03))' 
          }}>
            <Typography variant="subtitle1" fontWeight={600} sx={{ color: '#1976d2' }}>
              User Bills - {months[month]} {year}
            </Typography>
          </Box>
          <div className="ag-theme-alpine" style={{ width: '100%', height: '65vh' }}>
            <AgGridReact
              ref={gridRef}
              columnDefs={columnDefs}
              defaultColDef={defaultColDef}
              rowData={filtered}
              theme="legacy"
              headerHeight={40}
              rowHeight={50}
              animateRows
              pagination
              paginationPageSize={10}
              paginationPageSizeSelector={[10, 25, 50, 100]}
              sideBar={true}
              overlayNoRowsTemplate={'<span style="padding: 10px; display: inline-block;">No bills found for the selected period</span>'}
              quickFilterText={search}
            />
          </div>
        </Paper>
      )}

      {!loading && filtered.length === 0 && !error && (
        <Alert severity="info" sx={{ mt: 3 }}>
          No bills found for the selected period.
        </Alert>
      )}

      {/* User Bill Detail Dialog */}
      {selectedUser && (
        <UserBillDetail
          open={showUserBill}
          onClose={handleCloseUserBill}
          userId={selectedUser.userId}
          username={selectedUser.username}
          month={months[selectedUser.month]} // Pass month name (e.g., "August")
          year={selectedUser.year}
        />
      )}
    </Container>
  );
};

export default AdminUserBills;