import React, { useEffect, useState } from 'react';
import {
  Box,
  Typography,
  CircularProgress,
  Alert,
  Container,
  Grid,
  Paper,
  Chip
} from '@mui/material';
import {
  ReceiptLong as ReceiptIcon,
  CalendarToday as CalendarIcon,
  CheckCircle as CheckCircleIcon,
  Cancel as CancelIcon,
  Payments as PaymentsIcon
} from '@mui/icons-material';
import axios from 'axios';
import { AgGridReact } from 'ag-grid-react';
import { ModuleRegistry, AllCommunityModule } from 'ag-grid-community';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import './UserMonthBill.css';
// Register AG Grid Community modules
ModuleRegistry.registerModules([AllCommunityModule]);
const UserMonthBill = () => {
  const [bill, setBill] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [columnDefs] = useState([
    { headerName: 'Date', field: 'dateString', sortable: true, filter: true, flex: 1 },
    { headerName: 'Day', field: 'dayOfWeek', sortable: true, filter: true, flex: 1 },
    { headerName: 'Choice', field: 'choiceLabel', sortable: true, filter: true, flex: 1 },
    {
      headerName: 'Amount',
      field: 'amountNumber',
      type: 'numericColumn',
      flex: 1,
      valueFormatter: (params) => `Rs ${Number(params.value || 0).toLocaleString('en-IN')}`,
      cellStyle: { textAlign: 'right', fontWeight: 600 }
    }
  ]);
  
  // Helpers must be declared before they are used below
  const formatDate = (date) => new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  const formatMonthYear = (month, year) => `${month} ${year}`;
  const currency = (num) => `Rs ${Number(num || 0).toLocaleString('en-IN')}`;

  const [rows, setRows] = useState([]);

  useEffect(() => {
    if (!bill?.dailyBreakdown) {
      setRows([]);
      return;
    }
    const mapped = bill.dailyBreakdown.map(d => {
      const choiceUpper = (d.choice?.toString() || '').toUpperCase();
      const choiceLabel = choiceUpper === 'ACCEPT' ? 'Accepted' : choiceUpper === 'DENY' ? 'Denied' : choiceUpper;
      return {
        dateString: formatDate(d.date),
        dayOfWeek: d.dayOfWeek,
        choiceLabel,
        amountNumber: Number(d.amount || 0)
      };
    });
    setRows(mapped);
  }, [bill]);

  useEffect(() => {
    const fetchBill = async () => {
      setLoading(true);
      setError('');
      try {
        const res = await axios.get('/api/user/bill/current-month', {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${localStorage.getItem('userToken')}`
          }
        });
        setBill(res.data.bill || null);
      } catch (err) {
        setError(err.response?.data?.message || 'Failed to fetch bill');
      } finally {
        setLoading(false);
      }
    };
    fetchBill();
  }, []);

  

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="60vh">
        <CircularProgress size={60} sx={{ color: '#2e7d32' }} />
      </Box>
    );
  }

  if (error) {
    return (
      <Container maxWidth="md" sx={{ mt: 4 }}>
        <Alert severity="error" sx={{ fontSize: '1.05rem', py: 2 }}>{error}</Alert>
      </Container>
    );
  }

  if (!bill) {
    return (
      <Container maxWidth="sm" sx={{ mt: 6 }}>
        <Alert severity="info">No bill available for the current month.</Alert>
      </Container>
    );
  }

  const totalFromBreakdown = bill.dailyBreakdown?.reduce((sum, d) => sum + (d.amount || 0), 0) || 0;

  return (
    <Container maxWidth="lg" sx={{ pt: 2, pb: 0 }}>
      {/* Header */}
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <ReceiptIcon sx={{ color: '#2e7d32' }} />
          <Typography
            variant="h6"
            fontWeight={700}
            sx={{ color: '#1b5e20' }}
          >
            Current Month Bill
          </Typography>
        </Box>
        <Chip
          icon={<CalendarIcon />}
          label={formatMonthYear(bill.month, bill.year)}
          color="success"
          variant="outlined"
          sx={{ fontWeight: 600 }}
        />
      </Box>

      {/* Summary Cards */}
      {/* <Grid container spacing={2} sx={{ mb: 2 }}>
        <Grid item xs={12} sm={4}>
          <Paper elevation={4} sx={{ p: 2, borderRadius: 2, background: 'linear-gradient(135deg, #ffffff 0%, #f8fafc 100%)' }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <Box>
                <Typography variant="body2" color="text.secondary">Total Amount</Typography>
                <Typography variant="h6" fontWeight={700} color="success.main">{currency(bill.totalAmount)}</Typography>
              </Box>
              <PaymentsIcon sx={{ color: '#2e7d32', opacity: 0.8 }} />
            </Box>
          </Paper>
        </Grid>
        <Grid item xs={12} sm={4}>
          <Paper elevation={4} sx={{ p: 2, borderRadius: 2, background: 'linear-gradient(135deg, #ffffff 0%, #f8fafc 100%)' }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <Box>
                <Typography variant="body2" color="text.secondary">Accepted Days</Typography>
                <Typography variant="h6" fontWeight={700} color="success.main">{bill.acceptedDays}</Typography>
              </Box>
              <CheckCircleIcon sx={{ color: '#2e7d32', opacity: 0.8 }} />
            </Box>
          </Paper>
        </Grid>
        <Grid item xs={12} sm={4}>
          <Paper elevation={4} sx={{ p: 2, borderRadius: 2, background: 'linear-gradient(135deg, #ffffff 0%, #f8fafc 100%)' }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <Box>
                <Typography variant="body2" color="text.secondary">Denied Days</Typography>
                <Typography variant="h6" fontWeight={700} color="error.main">{bill.deniedDays}</Typography>
              </Box>
              <CancelIcon sx={{ color: '#d32f2f', opacity: 0.8 }} />
            </Box>
          </Paper>
        </Grid>
      </Grid> */}

      {/* Daily Breakdown - AG Grid */}
      <Paper elevation={8} sx={{ borderRadius: 3, overflow: 'hidden', mb: 5}}>
        <Box sx={{ p: 2.5, background: 'linear-gradient(135deg, rgba(46,125,50,0.05), rgba(46,125,50,0.03))' }}>
          <Typography variant="subtitle1" fontWeight={700} sx={{ color: '#2e7d32' }}>Daily Breakdown</Typography>
        </Box>
        <div className="ag-theme-alpine" style={{ width: '100%', height: 413 }}>
          <AgGridReact
            columnDefs={columnDefs}
            defaultColDef={{ resizable: true }}
            rowData={rows}
            theme="legacy"
            headerHeight={36}
            rowHeight={40}
            animateRows
            pagination
            paginationPageSize={10}
            sideBar={true}
            paginationPageSizeSelector={[10, 20, 50, 100]}
            overlayNoRowsTemplate={'<span style="padding: 10px; display: inline-block;">No rows to show</span>'}
            pinnedBottomRowData={[{
              dateString: 'Total',
              dayOfWeek: '',
              choiceLabel: '',
              amountNumber: Number(totalFromBreakdown || bill.totalAmount)
            }]}
          />
        </div>
      </Paper>
    </Container>
  );
};

export default UserMonthBill;