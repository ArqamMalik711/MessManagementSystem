import React, { useEffect, useState, useMemo } from 'react';
import { 
  Box, 
  Typography, 
  Paper, 
  Button, 
  Alert, 
  CircularProgress,
  Container,
  Chip,
  Autocomplete,
  TextField,
  IconButton,
  Tooltip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions
} from '@mui/material';
import RestaurantIcon from '@mui/icons-material/Restaurant';
import CalendarIcon from '@mui/icons-material/CalendarToday';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import SearchIcon from '@mui/icons-material/Search';
import axios from 'axios';
import { AgGridReact } from 'ag-grid-react';
import { ModuleRegistry, AllCommunityModule } from 'ag-grid-community';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import './Admin.css';
ModuleRegistry.registerModules([AllCommunityModule]);

const weekdays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

const AdminCreateMenu = () => {
  const [weekMenu, setWeekMenu] = useState([]);
  const [availableItems, setAvailableItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const [editOpen, setEditOpen] = useState(false);
  const [editIndex, setEditIndex] = useState(null);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);

  // Determine whether a given date (string) is editable today
  const isDateEditable = (dateStr) => {
    if (!dateStr) return true; // when date is not present, allow editing
    const now = new Date();
    const dayDate = new Date(dateStr);
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const dayStart = new Date(dayDate.getFullYear(), dayDate.getMonth(), dayDate.getDate());

    if (dayStart < todayStart) return false; // past days locked
    if (dayStart > todayStart) return true;  // future days editable

    // Same day: editable only until 10:00 AM
    const cutoff = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 10, 0, 0, 0);
    return now < cutoff;
  };

  const columnDefs = useMemo(() => ([
    { headerName: 'Day', field: 'dayOfWeek', flex: 1 },
    { 
      headerName: 'Date', 
      field: 'date', 
      flex: 1,
      valueFormatter: p => p.value ? new Date(p.value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : ''
    },
    {
      headerName: 'Items',
      field: 'items',
      flex: 2,
      valueGetter: p => Array.isArray(p.data?.items) ? p.data.items.map(it => it.item).filter(Boolean).join(', ') : ''
    },
    {
      headerName: 'Actions',
      field: 'actions',
      flex: 0.5,
      cellStyle:{ textAlign:'center'},
      cellRenderer: params => (
        <Tooltip title={isDateEditable(params.data?.date) ? "Edit" : "Locked"}
        componentsProps={{
          tooltip: {
            sx: {
              backgroundColor: "#1976d2", // or #1b5e20 for user
              color: "#fff",
              fontSize: "13px",
            },
          },
        }}
      >
          <span>
            <IconButton
              size="small"
              color="primary"
              onClick={() => handleOpenEdit(params.node.rowIndex)}
              sx={{ p: 0.5 }}
              disabled={!isDateEditable(params.data?.date)}
            >
              <EditIcon fontSize="small" />
            </IconButton>
          </span>
        </Tooltip>
      ),
      sortable: false,
      filter: false
    }
  ]), [weekMenu]);

  const defaultColDef = useMemo(() => ({ resizable: true, sortable: true, filter: true }), []);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      setError('');
      try {
        const token = localStorage.getItem('adminToken');
        
        // Fetch current week menu
        const menuRes = await axios.get('/api/admin/menu/current-week', {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`
          }
        });

        // Fetch all available items for dropdown
        const itemsRes = await axios.get('/api/admin/items/all', {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`
          }
        });

        setAvailableItems(itemsRes.data.items || []);

        if (menuRes.data.weekMenu && menuRes.data.weekMenu.length) {
          setWeekMenu(menuRes.data.weekMenu.map(day => ({
            ...day,
            items: day.items.length ? day.items : [{ item: '', range: '' }],
          })));
        } else {
          setWeekMenu(weekdays.map(day => ({ 
            dayOfWeek: day, 
            items: [{ item: '', range: '' }], 
            date: '', 
            hasMenu: false 
          })));
        }
      } catch (err) {
        setError(err.response?.data?.message || 'Failed to fetch data');
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const handleOpenEdit = (index) => {
    const day = weekMenu[index];
    if (day && !isDateEditable(day.date)) {
      setError('Editing is locked for this day. You can edit future days and today until 10:00 AM.');
      return;
    }
    setEditIndex(index);
    setEditOpen(true);
  };

  const handleCloseEdit = () => {
    setEditOpen(false);
    setEditIndex(null);
  };

  // Add new item to a specific day
  const handleAddItem = (dayIndex) => {
    setWeekMenu(prev => prev.map((day, idx) =>
      idx === dayIndex ? { ...day, items: [...day.items, { item: '', range: '' }] } : day
    ));
  };

  // Remove item from a specific day
  const handleRemoveItem = (dayIndex, itemIndex) => {
    setDeleteTarget({ dayIndex, itemIndex });
    setDeleteConfirmOpen(true);
  };

  const confirmDeleteItem = () => {
    if (deleteTarget) {
      const { dayIndex, itemIndex } = deleteTarget;
      setWeekMenu(prev => prev.map((day, idx) => {
        if (idx === dayIndex) {
          const newItems = day.items.filter((_, i) => i !== itemIndex);
          // Ensure at least one item remains
          if (newItems.length === 0) {
            newItems.push({ item: '', range: '' });
          }
          return { ...day, items: newItems };
        }
        return day;
      }));
      setDeleteConfirmOpen(false);
      setDeleteTarget(null);
    }
  };

  const cancelDeleteItem = () => {
    setDeleteConfirmOpen(false);
    setDeleteTarget(null);
  };

  // Handle item selection from dropdown
  const handleItemChange = (dayIndex, itemIndex, selectedItem) => {
    if (!selectedItem) return;
    
    setWeekMenu(prev => prev.map((day, idx) => {
      if (idx === dayIndex) {
        const newItems = [...day.items];
        newItems[itemIndex] = { 
          item: selectedItem.item, 
          range: selectedItem.range 
        };
        return { ...day, items: newItems };
      }
      return day;
    }));

    // Remove focus from the Autocomplete input so the user sees the selection is applied
    setTimeout(() => {
      const activeElement = document.activeElement;
      if (activeElement && typeof activeElement.blur === 'function') {
        activeElement.blur();
      }
    }, 0);
  };

  // Save menu
  const handleSubmit = async () => {
    setError('');
    setSuccess('');
    setSaving(true);
    try {
      for (let day of weekMenu) {
        const validItems = day.items.filter(it => it.item && it.range);
        if (validItems.length) {
          await axios.post(`/api/admin/menu/${day.date || ''}`, {
            items: validItems.map(it => ({ item: it.item, range: it.range }))
          }, {
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${localStorage.getItem('adminToken')}`
            }
          });
        }
      }
      setSuccess('Menu updated successfully!');
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to update menu');
    } finally {
      setSaving(false);
    }
  };

  if (loading) return (
    <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '50vh' }}>
      <CircularProgress size={60} />
    </Box>
  );

  return (
    <Container maxWidth="lg" sx={{ pt: 2, pb: 0 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            gap: 1.25,
          }}
        >
          <RestaurantIcon sx={{ color: '#1976d2' }} />
          <Typography
            variant="h6"
            fontWeight={700}
            sx={{ color: '#1976d2' }}
          >
            Create / Update Weekly Menu
          </Typography>
        </Box>
      </Box>

      <Paper elevation={8} sx={{ borderRadius: 3, overflow: 'hidden', mb: 3 }}>
        <Box sx={{ p: 2.5, background: 'linear-gradient(135deg, rgba(25,118,210,0.05), rgba(25,118,210,0.03))' }}>
          <Typography variant="subtitle1" fontWeight={700} sx={{ color: '#1976d2' }}>
            This Week
          </Typography>
        </Box>
        <div className="ag-theme-alpine" style={{ width: '100%' }}>
          <AgGridReact
            columnDefs={columnDefs}
            theme="legacy"
            defaultColDef={defaultColDef}
            rowData={weekMenu}
            headerHeight={36}
            rowHeight={44}
            animateRows
            domLayout="autoHeight"
            overlayNoRowsTemplate={'<span style="padding: 10px; display: inline-block;">No days to show</span>'}
          />
        </div>
      </Paper>

      {error && (
        <Alert severity="error" sx={{ mt: 3, borderRadius: 2, fontSize: 15 }}>
          {error}
        </Alert>
      )}
      
      {success && (
        <Alert severity="success" sx={{ mt: 3, borderRadius: 2, fontSize: 15 }}>
          {success}
        </Alert>
      )}

      <Button
        variant="contained"
        color="primary"
        sx={{ 
          mt: 2, 
          fontWeight: 700, 
          fontSize: 17, 
          px: 5, 
          py: 1.5, 
          borderRadius: 3, 
          boxShadow: '0 4px 16px rgba(25,118,210,0.13)', 
          textTransform: 'none', 
          transition: 'background 0.2s, box-shadow 0.2s', 
          background: saving ? '#bdbdbd' : 'linear-gradient(90deg, #1976d2 70%, #64b5f6 100%)', 
          '&:hover': { 
            background: saving ? '#bdbdbd' : 'linear-gradient(90deg, #1565c0 70%, #42a5f5 100%)', 
            boxShadow: '0 8px 32px rgba(25,118,210,0.22)' 
          } 
        }}
        onClick={handleSubmit}
        disabled={saving}
      >
        {saving ? <CircularProgress size={24} /> : 'Save Weekly Menu'}
      </Button>

      {/* Edit Day Dialog */}
      <Dialog open={editOpen} onClose={handleCloseEdit} maxWidth="md" fullWidth>
      <DialogTitle sx={{ color: 'white', backgroundColor: '#1976d2' }}>
          Edit Menu - {editIndex != null ? (weekMenu[editIndex]?.dayOfWeek || '') : ''}
        </DialogTitle>
        <DialogContent dividers>
          {editIndex != null && (
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              {(weekMenu[editIndex]?.items || []).map((item, itemIndex) => (
                <Box
                  key={itemIndex}
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 2,
                    p: 2,
                    border: '1px solid #e0e0e0',
                    borderRadius: 2,
                    backgroundColor: '#fafafa'
                  }}
                >
                  <Box sx={{ flex: 1, }}>
                    <Autocomplete
                      options={availableItems}
                      getOptionLabel={(option) => option.item}
                      value={availableItems.find(opt => opt.item === item.item) || null}
                      onChange={(_, newValue) => handleItemChange(editIndex, itemIndex, newValue)}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          label="Select Item"
                          placeholder="Search and select an item..."
                          InputProps={{
                            ...params.InputProps,
                            startAdornment: (
                              <>
                                <SearchIcon sx={{ color: 'text.secondary', mr: 1 }} />
                                {params.InputProps.startAdornment}
                              </>
                            )
                          }}
                        />
                      )}
                      renderOption={(props, option) => (
                        <Box component="li" {...props}>
                          <Box sx={{ display: 'flex', flexDirection: 'column', width: '100%' }}>
                            <Typography variant="body1" fontWeight={600}>
                              {option.item}
                            </Typography>
                            <Typography variant="body2" color="text.secondary">
                              Range: {option.range}
                            </Typography>
                          </Box>
                        </Box>
                      )}
                      filterOptions={(options, { inputValue }) => {
                        const filtered = options.filter(option =>
                          option.item.toLowerCase().includes(inputValue.toLowerCase())
                        );
                        return filtered.slice(0, 4);
                      }}
                    />
                  </Box>

                  <Box sx={{ minWidth: 120, textAlign: 'center' }}>
                    <Typography variant="body2" color="text.secondary" gutterBottom>
                      Range
                    </Typography>
                    <Typography variant="h6" fontWeight={600} color="primary">
                      {item.range || 'Not selected'}
                    </Typography>
                  </Box>

                  <Tooltip title="Remove Item"
                  componentsProps={{
                    tooltip: {
                      sx: {
                        backgroundColor: "#1976d2", // or #1b5e20 for user
                        color: "#fff",
                        fontSize: "13px",
                      },
                    },
                  }}
                >
                    <IconButton
                      color="error"
                      onClick={() => handleRemoveItem(editIndex, itemIndex)}
                      disabled={(weekMenu[editIndex]?.items || []).length === 1}
                      sx={{ 
                        backgroundColor: '#ffebee',
                        '&:hover': { backgroundColor: '#ffcdd2' }
                      }}
                    >
                      <DeleteIcon />
                    </IconButton>
                  </Tooltip>
                </Box>
              ))}

              <Box>
                <Button
                  startIcon={<AddIcon />}
                  onClick={() => handleAddItem(editIndex)}
                  variant="outlined"
                  color="primary"
                  sx={{ fontWeight: 600, borderRadius: 2 }}
                >
                  Add Item
                </Button>
              </Box>
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseEdit} variant="outlined">Close</Button>
        </DialogActions>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteConfirmOpen} onClose={cancelDeleteItem} maxWidth="sm" fullWidth>
      <DialogTitle sx={{ pt: 1,pb:1, color: 'white', backgroundColor: '#1976d2' }}>
          Confirm Delete
        </DialogTitle>
        <DialogContent sx={{mt:2,mb:0}}>
          <Typography>
            Are you sure you want to delete this item? This action cannot be undone.
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={cancelDeleteItem} variant="outlined">
            Cancel
          </Button>
          <Button onClick={confirmDeleteItem} variant="contained" color="error">
            Delete
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default AdminCreateMenu;