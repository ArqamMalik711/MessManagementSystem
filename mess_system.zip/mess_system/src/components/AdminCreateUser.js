import React, { useState } from 'react';
import { 
  Box, 
  Typography, 
  Paper, 
  Button, 
  Stack, 
  TextField, 
  Alert, 
  CircularProgress, 
  IconButton, 
  InputAdornment,
  Container,
  Grid,
  Card,
  CardContent,
  Chip,
  Avatar,
  Divider
} from '@mui/material';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import PersonAddAlt1Icon from '@mui/icons-material/PersonAddAlt1';
import PersonOutlineIcon from '@mui/icons-material/PersonOutline';
import VisibilityIcon from '@mui/icons-material/Visibility';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import LockIcon from '@mui/icons-material/Lock';
import axios from 'axios';

const AdminCreateUser = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [token, setToken] = useState('');
  const [copied, setCopied] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');
    setToken('');
    setCopied(false);
    try {
      const adminToken = localStorage.getItem('adminToken');
      const res = await axios.post('/api/admin/users', {
        username,
        password
      }, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`
        }
      });
      setSuccess(res.data.message || 'User created successfully!');
      setToken(res.data.token);
      setUsername('');
      setPassword('');
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to create user');
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (token) {
      navigator.clipboard.writeText(token);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <Container maxWidth="lg" sx={{ pt: 2, pb: 0 }}>
      {/* Header */}
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            gap: 1,
          }}
        >
          <PersonAddAlt1Icon sx={{ color: '#1976d2' }} />
          <Typography
          variant="h6"
          fontWeight={700}
          sx={{
            color: '#1976d2'
          }}
        >
          Create New User
        </Typography>
        </Box>
      </Box>

      {/* Form Card */}
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
      <Paper elevation={8} sx={{ p: { xs: 2, sm: 3 }, borderRadius: 3,display: 'flex', justifyContent: 'center', alignItems: 'center', background: 'linear-gradient(135deg, #ffffff 0%, #f8fafc 100%)', mb: 5, width: { lg: '40%', xs: '100%', sm: '80%', md: '60%' }, maxWidth: 720 }}>
          <form onSubmit={handleSubmit}>
            <Grid container spacing={2}>
              <Grid item xs={12} width={'100%'}>
                <TextField
                  label="Username"
                  value={username}
                  onChange={e => setUsername(e.target.value)}
                  required
                  fullWidth
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <PersonOutlineIcon sx={{ color: '#1976d2' }} />
                      </InputAdornment>
                    )
                  }}
                />
              </Grid>
              <Grid item xs={12} width={'100%'}>
                <TextField
                  label="Password"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  required
                  fullWidth
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <LockIcon sx={{ color: '#1976d2' }} />
                      </InputAdornment>
                    ),
                    endAdornment: (
                      <InputAdornment position="end">
                        <IconButton onClick={() => setShowPassword(!showPassword)} edge="end">
                          {showPassword ? <VisibilityOffIcon /> : <VisibilityIcon />}
                        </IconButton>
                      </InputAdornment>
                    )
                  }}
                  helperText="Minimum 6-8 characters recommended."
                />
              </Grid>
              </Grid>

              {error && (
                <Grid item xs={12}>
                  <Alert severity="error" sx={{ borderRadius: 2, fontSize: 15, boxShadow: '0 2px 8px rgba(211,47,47,0.08)' }}>
                    {error}
                  </Alert>
                </Grid>
              )}
              {success && (
                <Grid item xs={12}>
                  <Alert severity="success" sx={{ borderRadius: 2, fontSize: 15, boxShadow: '0 2px 8px rgba(46,125,50,0.08)' }}>
                    {success}
                  </Alert>
                </Grid>
              )}

              
                <Button
                  type="submit"
                  variant="contained"
                  color="primary"
                  disabled={loading}
                  fullWidth
                  sx={{
                    mt: 3,
                    fontWeight: 700,
                    fontSize: 17,
                    px: 5,
                    py: 1.5,
                    borderRadius: 3,
                    boxShadow: '0 4px 16px rgba(25,118,210,0.13)',
                    textTransform: 'none',
                    transition: 'background 0.2s, box-shadow 0.2s',
                    background: loading ? '#bdbdbd' : 'linear-gradient(90deg, #1976d2 70%, #64b5f6 100%)',
                    '&:hover': {
                      background: loading ? '#bdbdbd' : 'linear-gradient(90deg, #1565c0 70%, #42a5f5 100%)',
                      boxShadow: '0 8px 32px rgba(25,118,210,0.22)',
                    },
                    mb:0
                  }}
                >
                  {loading ? <CircularProgress size={24} /> : 'Create User'}
                </Button>
              

              {/* {token && (
                <Grid item xs={12}>
                  <Divider sx={{ my: 1.5 }} />
                  <Typography variant="subtitle1" gutterBottom sx={{ color: '#1976d2', fontWeight: 600 }}>
                    User Token Generated Successfully
                  </Typography>
                  <TextField
                    value={token}
                    fullWidth
                    InputProps={{
                      readOnly: true,
                      endAdornment: (
                        <InputAdornment position="end">
                          <IconButton onClick={handleCopy} edge="end" sx={{ color: '#1976d2' }}>
                            <ContentCopyIcon />
                          </IconButton>
                        </InputAdornment>
                      )
                    }}
                  />
                  {copied && (
                    <Typography color="success.main" variant="caption" sx={{ mt: 1, display: 'block' }}>
                      ✓ Token copied to clipboard!
                    </Typography>
                  )}
                </Grid>
              )} */}
            
          </form>
      </Paper>
      </div>
    </Container>
  );
};

export default AdminCreateUser;
