import React, { useEffect, useState } from 'react';
import {
  Box,
  Typography,
  CircularProgress,
  Alert,
  Container,
  Paper,
  Chip,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Grid
} from '@mui/material';
import {
  ReceiptLong as ReceiptIcon,
  CalendarToday as CalendarIcon,
  CheckCircle as CheckCircleIcon,
  Cancel as CancelIcon,
  Close as CloseIcon
} from '@mui/icons-material';
import axios from 'axios';
import { AgGridReact } from 'ag-grid-react';
import { ModuleRegistry, AllCommunityModule } from 'ag-grid-community';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import './Admin.css';

// Register AG Grid Community modules
ModuleRegistry.registerModules([AllCommunityModule]);

const months = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

const UserBillDetail = ({ open, onClose, userId, username, month, year }) => {
  const [bill, setBill] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [rows, setRows] = useState([]);

  const [columnDefs] = useState([
    { 
      headerName: 'Date', 
      field: 'dateString', 
      sortable: true, 
      filter: true, 
      flex: 1,
      cellStyle: { fontWeight: 600 }
    },
    { 
      headerName: 'Day', 
      field: 'dayOfWeek', 
      sortable: true, 
      filter: true, 
      flex: 1 
    },
    { 
      headerName: 'Choice', 
      field: 'choiceLabel', 
      sortable: true, 
      filter: true, 
      flex: 1,
      cellRenderer: params => {
        const choice = params.value;
        const color = choice === 'Accepted' ? 'success' : 'default';
        return (
          <Chip
            label={choice}
            color={color}
            size="small"
            variant="outlined"
            sx={{ fontWeight: 600 }}
          />
        );
      }
    },
    {
      headerName: 'Amount',
      field: 'amountNumber',
      type: 'numericColumn',
      flex: 1,
      valueFormatter: (params) => `Rs ${Number(params.value || 0).toLocaleString('en-IN')}`,
      cellStyle: { textAlign: 'right', fontWeight: 600 }
    }
  ]);

  // Helper functions
  const formatDate = (date) => new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  const formatMonthYear = (month, year) => `${month} ${year}`;
  const currency = (num) => `Rs ${Number(num || 0).toLocaleString('en-IN')}`;

  useEffect(() => {
    if (!open || !userId) return;

    const fetchBill = async () => {
      setLoading(true);
      setError('');
      try {
        // month is passed as month name (e.g., "August"), convert to month index (0-11) for API
        const monthIndex = months.indexOf(month);
        if (monthIndex === -1) {
          throw new Error('Invalid month name');
        }
        console.log('Fetching bill for:', { userId, month, monthIndex, year });
        const res = await axios.get(`/api/admin/user-bill/${userId}/${monthIndex}/${year}`, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${localStorage.getItem('adminToken')}`
          }
        });
        setBill(res.data.bill || null);
      } catch (err) {
        console.error('Error fetching bill:', err);
        setError(err.response?.data?.message || 'Failed to fetch bill');
      } finally {
        setLoading(false);
      }
    };

    fetchBill();
  }, [open, userId, month, year]);

  useEffect(() => {
    if (!bill?.dailyBreakdown) {
      setRows([]);
      return;
    }
    
    const mapped = bill.dailyBreakdown.map(d => {
      const choiceUpper = (d.choice?.toString() || '').toUpperCase();
      const choiceLabel = choiceUpper === 'ACCEPT' ? 'Accepted' : choiceUpper === 'DENY' ? 'Denied' : choiceUpper;
      return {
        dateString: formatDate(d.date),
        dayOfWeek: d.dayOfWeek,
        choiceLabel,
        amountNumber: Number(d.amount || 0)
      };
    });
    setRows(mapped);
  }, [bill]);

  const totalFromBreakdown = bill?.dailyBreakdown?.reduce((sum, d) => sum + (d.amount || 0), 0) || 0;

  const handleClose = () => {
    setBill(null);
    setRows([]);
    setError('');
    onClose();
  };

  return (
    <Dialog 
      open={open} 
      onClose={handleClose} 
      maxWidth="lg" 
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: 3,
          minHeight: '80vh'
        }
      }}
    >
      <DialogTitle sx={{ 
        m: 0, 
        p: 3, 
        background: 'linear-gradient(135deg, #1976d2, #1565c0)',
        color: 'white',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between'
      }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          <ReceiptIcon />
          <Box>
            <Typography variant="h5" fontWeight={700}>
              {username}'s Monthly Bill
            </Typography>
            <Typography variant="body1" sx={{ opacity: 0.9 }}>
              {formatMonthYear(month, year)}
            </Typography>
          </Box>
        </Box>
        <IconButton
          aria-label="close"
          onClick={handleClose}
          sx={{
            color: 'white',
            '&:hover': { backgroundColor: 'rgba(255,255,255,0.1)' }
          }}
        >
          <CloseIcon />
        </IconButton>
      </DialogTitle>

      <DialogContent sx={{ p: 3 }}>
        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '40vh' }}>
            <CircularProgress size={60} />
          </Box>
        ) : error ? (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        ) : !bill ? (
          <Alert severity="info">
            No bill available for this user in the selected period.
          </Alert>
        ) : (
          <>
            

            {/* Daily Breakdown - AG Grid */}
            <Paper elevation={8} sx={{ borderRadius: 3, overflow: 'hidden' }}>
              <Box sx={{ 
                p: 2.5, 
                background: 'linear-gradient(135deg, rgba(25,118,210,0.05), rgba(25,118,210,0.03))' 
              }}>
                <Typography variant="subtitle1" fontWeight={700} sx={{ color: '#1976d2' }}>
                  Daily Breakdown
                </Typography>
              </Box>
              <div className="ag-theme-alpine" style={{ width: '100%', height: 400 }}>
                <AgGridReact
                  columnDefs={columnDefs}
                  defaultColDef={{ resizable: true }}
                  rowData={rows}
                  theme="legacy"
                  headerHeight={36}
                  rowHeight={40}
                  animateRows
                  pagination
                  paginationPageSize={10}
                  sideBar={true}
                  paginationPageSizeSelector={[10, 20, 50, 100]}
                  overlayNoRowsTemplate={'<span style="padding: 10px; display: inline-block;">No rows to show</span>'}
                  pinnedBottomRowData={[{
                    dateString: 'Total',
                    dayOfWeek: '',
                    choiceLabel: '',
                    amountNumber: Number(totalFromBreakdown || bill.totalAmount)
                  }]}
                />
              </div>
            </Paper>
          </>
        )}
      </DialogContent>

      <DialogActions sx={{ p: 3, pb:1,pt: 0 }}>
        <Button onClick={handleClose} variant="outlined">
          Close
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default UserBillDetail;
