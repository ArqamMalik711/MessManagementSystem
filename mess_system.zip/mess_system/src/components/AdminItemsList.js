import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Box, Typography, Container, Paper, TextField, Button, Alert, InputAdornment, IconButton, Tooltip, Dialog, DialogTitle, DialogContent, DialogActions } from '@mui/material';
import { Restaurant as RestaurantIcon, Search as SearchIcon, Save as SaveIcon, Edit as EditIcon, Delete as DeleteIcon } from '@mui/icons-material';
import axios from 'axios';
import { AgGridReact } from 'ag-grid-react';
import { ModuleRegistry, AllCommunityModule } from 'ag-grid-community';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import './Admin.css';

ModuleRegistry.registerModules([AllCommunityModule]);

const AdminItemsList = () => {
  const [rowData, setRowData] = useState([]);
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');
  const [search, setSearch] = useState('');
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const gridRef = useRef(null);

  const columnDefs = useMemo(
    () => [
      {
        headerName: '#',
        field: 'index',
        valueGetter: params => {
          const page = params.api.paginationGetCurrentPage ? params.api.paginationGetCurrentPage() : 0;
          const size = params.api.paginationGetPageSize ? params.api.paginationGetPageSize() : 0;
          return page * size + (params.node.rowIndex ?? 0) + 1;
        },
        width: 80,
        maxWidth: 90,
        pinned: 'left',
        cellStyle: { textAlign: 'center', fontWeight: 600 },
        sortable: false,
        filter: false,
        resizable: false
      },
      { headerName: 'Item', field: 'item', editable: true, flex: 2 },
      { 
        headerName: 'Range', 
        field: 'range', 
        editable: true, 
        flex: 1,
        cellStyle: { textAlign: 'center', fontWeight: 600 }
      },
      {
        headerName: 'Actions',
        field: 'actions',
        width: 120,
        maxWidth: 120,
        pinned: 'right',
        sortable: false,
        filter: false,
        resizable: false,
        cellRenderer: params => {
          const data = params.data;
          return (
            <Box sx={{ display: 'flex', gap: 0.5, justifyContent: 'center' }}>
              <Tooltip title="Edit"
              componentsProps={{
                tooltip: {
                  sx: {
                    backgroundColor: "#1976d2", // or #1b5e20 for user
                    color: "#fff",
                    fontSize: "13px",
                  },
                },
              }}
            >
                <IconButton
                  size="small"
                  color="primary"
                  onClick={() => handleEditRow(data)}
                  sx={{ p: 0.5 }}
                >
                  <EditIcon fontSize="small" />
                </IconButton>
              </Tooltip>
              <Tooltip title="Delete"
              componentsProps={{
                tooltip: {
                  sx: {
                    backgroundColor: "#1976d2", // or #1b5e20 for user
                    color: "#fff",
                    fontSize: "13px",
                  },
                },
              }}
            >
                <IconButton
                  size="small"
                  color="error"
                  onClick={() => handleDeleteRow(data)}
                  sx={{ p: 0.5 }}
                >
                  <DeleteIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            </Box>
          );
        }
      }
    ],
    []
  );

  const defaultColDef = useMemo(
    () => ({ resizable: true, sortable: true, filter: true }),
    []
  );

  const fetchItems = async (q = '') => {
    setError('');
    try {
      const res = await axios.get('/api/admin/items', {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${localStorage.getItem('adminToken')}`
        },
        params: { q }
      });
      setRowData(res.data.items || []);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to load items');
    }
  };

  useEffect(() => { fetchItems(); }, []);

  // Keep grid quick filter in sync with the search field for instant filtering (compat via prop)
  // We will rely on the quickFilterText prop on AgGridReact for maximum compatibility

  const handleAddRow = () => {
    setRowData(prev => [{ item: '', range: '', _new: true }, ...prev]);
  };

  const handleEditRow = (rowData) => {
    // Enable editing for the specific row
    const api = gridRef.current?.api;
    const rowNode = api?.getRowNode(rowData._id || rowData._new);
    if (rowNode) {
      api?.startEditingCell({ rowIndex: rowNode.rowIndex, colKey: 'item' });
    }
  };

  const handleDeleteRow = async (rowData) => {
    if (!rowData._id) {
      // Remove new row from local state
      setRowData(prev => prev.filter(row => row !== rowData));
      return;
    }

    setDeleteTarget(rowData);
    setDeleteConfirmOpen(true);
  };

  const confirmDeleteRow = async () => {
    if (deleteTarget) {
      try {
        await axios.delete(`/api/admin/items/${deleteTarget._id}`, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${localStorage.getItem('adminToken')}`
          }
        });
        setInfo('Item deleted successfully');
        await fetchItems(search);
      } catch (err) {
        setError(err.response?.data?.message || 'Delete failed');
      }
      setDeleteConfirmOpen(false);
      setDeleteTarget(null);
    }
  };

  const cancelDeleteRow = () => {
    setDeleteConfirmOpen(false);
    setDeleteTarget(null);
  };

  const handleSave = async () => {
    setError('');
    setInfo('');
    const api = gridRef.current?.api;
    api?.stopEditing();
    const rows = [];
    api?.forEachNode(node => rows.push(node.data));

    try {
      for (const r of rows) {
        if (!r.item || !r.range) continue;
        if (r._id) {
          await axios.put(`/api/admin/items/${r._id}`, { item: r.item, range: r.range }, {
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${localStorage.getItem('adminToken')}`
            }
          });
        } else {
          await axios.post('/api/admin/items', { item: r.item, range: r.range }, {
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${localStorage.getItem('adminToken')}`
            }
          });
        }
      }
      setInfo('Items saved');
      await fetchItems(search);
    } catch (err) {
      setError(err.response?.data?.message || 'Save failed');
    }
  };

  return (
    <Container maxWidth="lg" sx={{ pt: 2, pb: 0 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.25 }}>
          <RestaurantIcon sx={{ color: '#1976d2' }} />
          <Typography variant="h6" fontWeight={700} sx={{ color: '#1976d2' }}>
            Items List
          </Typography>
        </Box>
        <Box sx={{ display: 'flex', gap: 1 }}>
          <TextField
            placeholder="Search items"
            value={search}
            onChange={e => setSearch(e.target.value)}
            size="small"
            InputProps={{ startAdornment: (
              <InputAdornment position="start">
                <SearchIcon sx={{ mr: 0.5, color: 'text.secondary' }} />
              </InputAdornment>
            ) }}
            onKeyDown={e => { if (e.key === 'Enter') fetchItems(search); }}
          />
          <Button variant="outlined" onClick={() => fetchItems(search)}>Search</Button>
          <Button variant="contained" startIcon={<SaveIcon />} onClick={handleSave}>Save</Button>
          <Button variant="text" onClick={handleAddRow}>Add Row</Button>
          <Button variant="text" onClick={() => gridRef.current?.api?.exportDataAsCsv()}>
            Export CSV
          </Button>
          <Button
            variant="text"
            onClick={() => {
              const api = gridRef.current?.api;
              const columnApi = gridRef.current?.columnApi;
              api?.setFilterModel(null);
              columnApi?.applyColumnState({ defaultState: { sort: null } });
            }}
          >
            Clear Sort/Filters
          </Button>
        </Box>
      </Box>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
      {info && <Alert severity="success" sx={{ mb: 2 }}>{info}</Alert>}

      <Paper elevation={8} sx={{ borderRadius: 3, overflow: 'hidden', mb: 5 }}>
        <div className="ag-theme-alpine" style={{ width: '100%', height: 460 }}>
          <AgGridReact
            ref={gridRef}
            rowData={rowData}
            theme="legacy"
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}
            editType="fullRow"
            stopEditingWhenCellsLoseFocus
            enableCellTextSelection
            rowSelection="multiple"
            animateRows
            pagination
            paginationPageSize={10}
            paginationPageSizeSelector={[10, 20, 50, 100]}
            headerHeight={36}
            rowHeight={40}
            overlayNoRowsTemplate={'<span style="padding: 10px; display: inline-block;">No items</span>'}
            quickFilterText={search}
          />
        </div>
      </Paper>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteConfirmOpen} onClose={cancelDeleteRow} maxWidth="sm" fullWidth>
        <DialogTitle sx={{ pt: 1,pb:1, color: 'white', backgroundColor: '#1976d2' }}>
          Confirm Delete
        </DialogTitle>
        <DialogContent sx={{mt:2,mb:0}}>
          <Typography>
            Are you sure you want to delete "{deleteTarget?.item}"? This action cannot be undone.
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={cancelDeleteRow} variant="outlined">
            Cancel
          </Button>
          <Button onClick={confirmDeleteRow} variant="contained" color="error">
            Delete
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default AdminItemsList;
