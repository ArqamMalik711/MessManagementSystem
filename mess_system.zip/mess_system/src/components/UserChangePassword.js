import React, { useState } from 'react';
import { Box, Typography, TextField, Button, Paper, Alert, CircularProgress, Container, Chip, Divider, InputAdornment, IconButton, Grid, LinearProgress } from '@mui/material';
import { Lock as LockIcon, Visibility as VisibilityIcon, VisibilityOff as VisibilityOffIcon, VerifiedUser as VerifiedUserIcon, InfoOutlined as InfoIcon, CheckCircle as CheckIcon } from '@mui/icons-material';
import axios from 'axios';

const UserChangePassword = () => {
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const getStrength = (password) => {
    let score = 0;
    if (password.length >= 8) score += 1;
    if (/[A-Z]/.test(password)) score += 1;
    if (/[a-z]/.test(password)) score += 1;
    if (/\d/.test(password)) score += 1;
    if (/[^A-Za-z0-9]/.test(password)) score += 1;

    const labels = ['Very Weak', 'Weak', 'Fair', 'Good', 'Strong'];
    const colors = ['error', 'error', 'warning', 'info', 'success'];
    const clamped = Math.min(score, 5);
    return {
      label: labels[clamped - 1] || 'Very Weak',
      color: colors[clamped - 1] || 'error',
      value: (clamped / 5) * 100,
    };
  };

  const strength = getStrength(newPassword);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!currentPassword || !newPassword) {
      setError('Please fill in all required fields.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setError('New password and confirm password do not match.');
      return;
    }
    if (newPassword.length < 8) {
      setError('New password must be at least 8 characters long.');
      return;
    }

    setLoading(true);
    try {
      await axios.put('/api/user/change-password', { currentPassword, newPassword }, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${localStorage.getItem('userToken')}`
        }
      });
      setSuccess('Password changed successfully!');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to change password');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Container maxWidth="lg" sx={{ pt: 2, pb: 0 }}>
      {/* Header */}
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            gap: 1,
          }}
        >
          <VerifiedUserIcon sx={{ color: '#2e7d32' }} />
          <Typography
          variant="h6"
          fontWeight={700}
          sx={{
            color: '#1b5e20',
          }}
        >
          Change Password
        </Typography>
        </Box>

        {/* <Chip label="Secure Portal" color="success" variant="outlined" sx={{ mt: 0.5, fontWeight: 600 }} /> */}
      </Box>

      {/* Form Card */}
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
      <Paper
        elevation={8}
        sx={{
          p: { xs: 2, sm: 3 },
          borderRadius: 3,
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          background: 'linear-gradient(135deg, #ffffff 0%, #f8fafc 100%)',
          mb: 5,
          width: { lg: '40%', xs: '100%', sm: '80%', md: '60%' },
          maxWidth: 720
        }}
      >
        <form onSubmit={handleSubmit}>
          <Grid container spacing={2} >
            <Grid item xs={12} width={'100%'} >
              <TextField
                label="Current Password"
                type={showCurrent ? 'text' : 'password'}
                value={currentPassword}
                onChange={e => setCurrentPassword(e.target.value)}
                fullWidth
                required
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <LockIcon sx={{ color: '#2e7d32' }} />
                    </InputAdornment>
                  ),
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton onClick={() => setShowCurrent(!showCurrent)} edge="end">
                        {showCurrent ? <VisibilityOffIcon /> : <VisibilityIcon />}
                      </IconButton>
                    </InputAdornment>
                  )
                }}
              />
            </Grid>
            <Grid item xs={12} width={'100%'} >
              <TextField
                label="New Password"
                type={showNew ? 'text' : 'password'}
                value={newPassword}
                onChange={e => setNewPassword(e.target.value)}
                fullWidth
                required
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <LockIcon sx={{ color: '#2e7d32' }} />
                    </InputAdornment>
                  ),
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton onClick={() => setShowNew(!showNew)} edge="end">
                        {showNew ? <VisibilityOffIcon /> : <VisibilityIcon />}
                      </IconButton>
                    </InputAdornment>
                  )
                }}
                helperText="Minimum 8 characters with a mix of letters, numbers, and symbols."
              />
              {/* Strength Meter */}
              <Box sx={{ mt: 1 }}>
                <LinearProgress variant="determinate" value={strength.value} color={strength.color} sx={{ height: 6, borderRadius: 2 }} />
                <Typography variant="caption" sx={{ mt: 0.5, display: 'block', color: 'text.secondary' }}>
                  Strength: <b>{strength.label}</b>
                </Typography>
              </Box>
            </Grid>
            <Grid item xs={12} width={'100%'}>
              <TextField
                label="Confirm New Password"
                type={showConfirm ? 'text' : 'password'}
                value={confirmPassword}
                onChange={e => setConfirmPassword(e.target.value)}
                fullWidth
                required
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <LockIcon sx={{ color: '#2e7d32' }} />
                    </InputAdornment>
                  ),
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton onClick={() => setShowConfirm(!showConfirm)} edge="end">
                        {showConfirm ? <VisibilityOffIcon /> : <VisibilityIcon />}
                      </IconButton>
                    </InputAdornment>
                  )
                }}
              />
            </Grid>
          </Grid>

          {error && (
            <Alert severity="error" sx={{ mt: 3, borderRadius: 2, fontSize: 15, boxShadow: '0 2px 8px 0 rgba(211,47,47,0.08)' }}>
              {error}
            </Alert>
          )}
          {success && (
            <Alert icon={<CheckIcon fontSize="inherit" />} severity="success" sx={{ mt: 3, borderRadius: 2, fontSize: 15, boxShadow: '0 2px 8px 0 rgba(46,125,50,0.08)' }}>
              {success}
            </Alert>
          )}

          <Button
            type="submit"
            variant="contained"
            color="primary"
            fullWidth
            sx={{
              mt: 3,
              fontWeight: 700,
              fontSize: 17,
              px: 5,
              py: 1.5,
              borderRadius: 3,
              boxShadow: '0 4px 16px 0 rgba(46,125,50,0.13)',
              textTransform: 'none',
              transition: 'background 0.2s, box-shadow 0.2s',
              background: loading ? '#bdbdbd' : 'linear-gradient(90deg, #2e7d32 70%, #4caf50 100%)',
              '&:hover': {
                background: loading ? '#bdbdbd' : 'linear-gradient(90deg, #1b5e20 70%, #388e3c 100%)',
                boxShadow: '0 8px 32px 0 rgba(46,125,50,0.22)',
              },
              mb: 0
            }}
            disabled={loading}
          >
            {loading ? <CircularProgress size={24} /> : 'Change Password'}
          </Button>
        </form>
      </Paper>
      </div>
      
    </Container>
  );
};

export default UserChangePassword;