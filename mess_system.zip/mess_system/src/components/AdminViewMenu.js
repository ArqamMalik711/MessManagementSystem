import React, { useEffect, useState } from 'react';
import { 
  Box, 
  Typography, 
  Paper, 
  CircularProgress, 
  Alert, 
  Grid,
  Card,
  CardContent,
  Chip,
  Divider,
  IconButton,
  Tooltip,
  Container
} from '@mui/material';
import {
  Restaurant as RestaurantIcon,
  CalendarToday as CalendarIcon,
  AccessTime as TimeIcon,
  MonetizationOn as PriceIcon,
  Today as TodayIcon,
  CheckCircle as CheckIcon,
  Cancel as CancelIcon
} from '@mui/icons-material';
import axios from 'axios';

const AdminViewMenu = () => {
  const [weekMenu, setWeekMenu] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchMenu = async () => {
      setLoading(true);
      setError('');
      try {
        const res = await axios.get('/api/admin/menu/current-week', {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${localStorage.getItem('adminToken')}`
          }
        });
        setWeekMenu(res.data.weekMenu || []);
      } catch (err) {
        setError(err.response?.data?.message || 'Failed to fetch menu');
      } finally {
        setLoading(false);
      }
    };
    fetchMenu();
  }, []);

  // Use the same green theme as the user's Weekly Booking
  const dayColor = '#1976d2';

  const getDayColor = (dayOfWeek) => {
    const colors = {
      'Monday': '#1976d2',
      'Tuesday': '#1976d2',
      'Wednesday': '#1976d2',
      'Thursday': '#1976d2',
      'Friday': '#1976d2',
      'Saturday': '#1976d2',
      'Sunday': '#1976d2'
    };
    return colors[dayOfWeek] || '#1976d2';
  };


  const weeklyTotal = weekMenu.reduce((total, day) =>
    total + (day.items?.reduce((sum, item) => {
      // Extract numeric value from range (e.g., "500-1000" -> 750)
      const rangeParts = (item.range || '').split('-');
      if (rangeParts.length === 2) {
        const min = parseInt(rangeParts[0]) || 0;
        const max = parseInt(rangeParts[1]) || 0;
        return sum + Math.round((min + max) / 2);
      }
      return sum;
    }, 0) || 0),
  0);
  const weeklyMin = Math.max(0, weeklyTotal - 250);
  const weeklyMax = weeklyTotal + 250;


  const getDayIcon = (dayOfWeek) => {
    const icons = {
      'Monday': '📅',
      'Tuesday': '📅',
      'Wednesday': '📅',
      'Thursday': '📅',
      'Friday': '📅',
      'Saturday': '📅',
      'Sunday': '📅'
    };
    return icons[dayOfWeek] || '📅';
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="60vh">
        <CircularProgress size={60} sx={{ color: '#1976d2' }} />
      </Box>
    );
  }

  if (error) {
    return (
      <Container maxWidth="md" sx={{ mt: 4 }}>
        <Alert severity="error" sx={{ fontSize: '1.1rem', py: 2 }}>
          {error}
        </Alert>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ pt: 2, pb: 0 }}>
      {/* Header - aligned and styled like Weekly Booking */}
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.25 }}>
          <RestaurantIcon sx={{ color: dayColor }} />
          <Typography variant="h6" fontWeight={700} sx={{ color: '#1976d2' }}>
            Weekly Menu Overview
          </Typography>
        </Box>
      </Box>

      {/* Menu Grid */}
      <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 1.5 }}>
        {weekMenu.map(({ date, dayOfWeek, items, hasMenu }, idx) => (
            <Card
              elevation={8}
              sx={{
                width: '100%',
                height: 300,
                minHeight: 240,
                display: 'flex',
                flexDirection: 'column',
                borderRadius: 2,
                background: 'linear-gradient(135deg, #ffffff 0%, #f8fafc 100%)',
                border: `2px solid ${getDayColor(dayOfWeek)}20`,
                transition: 'all 0.3s ease',
                position: 'relative',
                overflow: 'hidden',
                '&:hover': {
                  transform: 'translateY(-4px)',
                  // boxShadow: `0 20px 40px ${getDayColor(dayOfWeek)}30`,
                  // borderColor: `${getDayColor(dayOfWeek)}40`,
                },
                // '&::before': {
                //   content: '""',
                //   position: 'absolute',
                //   top: 0,
                //   left: 0,
                //   right: 0,
                //   height: 3,
                //   background: 'linear-gradient(90deg, #2e7d32, #1b5e20)',
                //   borderTopLeftRadius: 'inherit',
                //   borderTopRightRadius: 'inherit'
                // }
              }}
            >
              <CardContent sx={{ p: 2, height: '100%', display: 'flex', flexDirection: 'column', flex: 1 }}>
                {/* Day Header */}
                <Box sx={{ display: 'flex', alignItems: 'center', mb: -2 }}>
                  {/* <Typography
                    variant="h2"
                    sx={{ fontSize: '2.5rem', mr: 1, filter: 'grayscale(0.3)' }}
                  >
                    {getDayIcon(dayOfWeek)}
                  </Typography> */}
                  <Box sx={{ flex: 1 }}>
                    <Typography
                      variant="subtitle1"
                      fontWeight={700}
                      sx={{ color: dayColor }}
                    >
                      {dayOfWeek}
                    </Typography>
                    {/* <Typography variant="body2" color="text.secondary" sx={{ display: 'flex', alignItems: 'center' }}>
                      <TodayIcon sx={{ fontSize: 16, mr: 0.5 }} />
                      {new Date(date).toLocaleDateString('en-US', { 
                        month: 'short', 
                        day: 'numeric' 
                      })}
                    </Typography> */}
                  </Box>
                  {/* <Chip
                    icon={hasMenu ? <CheckIcon /> : <CancelIcon />}
                    color={hasMenu ? 'success' : 'default'}
                    size="small"
                    variant={hasMenu ? 'filled' : 'outlined'}
                    sx={{ fontWeight: 600 }}
                  /> */}
                </Box>

                <Divider sx={{ my: 2, opacity: 0.3 }} />

                {/* Menu Items */}
                {hasMenu ? (
                  <Box sx={{ flex: 1, minHeight: 60, position: 'relative' }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 0.5 }}>
                      <Typography variant="subtitle2" fontWeight={700} sx={{ color: 'text.primary', opacity: 0.8 }}>
                        Items
                      </Typography>
                    </Box>
                    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.75 }}>
                      {items.map((item, i) => (
                        <Box
                          key={i}
                          sx={{
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'center',
                            p: 1,
                            borderRadius: 2,
                            background: 'rgba(25,118,210,0.05)',
                            border: '1px solid rgba(25,118,210,0.1)'
                          }}
                        >
                          <Typography variant="body2" fontWeight={600}>{item.item}</Typography>
                          <Chip
                            label={`${item.range}/-`}
                            size="small"
                            color="primary"
                            variant="outlined"
                            sx={{ fontWeight: 600 }}
                          />
                        </Box>
                      ))}
                    </Box>
                  </Box>
                ) : (
                  <Box
                    sx={{
                      flex: 1,
                      display: 'flex',
                      flexDirection: 'column',
                      justifyContent: 'center',
                      alignItems: 'center',
                      py: 4,
                      opacity: 0.6
                    }}
                  >
                    <CancelIcon sx={{ fontSize: 48, color: 'text.secondary', mb: 2 }} />
                    <Typography variant="h6" color="text.secondary" sx={{ textAlign: 'center' }}>
                      No Menu Available
                    </Typography>
                    <Typography variant="body2" color="text.secondary" sx={{ textAlign: 'center', mt: 1 }}>
                      Check back later for updates
                    </Typography>
                  </Box>
                )}

                {/* Footer Stats */}
                {/* {hasMenu && (
                  <Box sx={{ mt: 3, pt: 2, borderTop: '1px solid rgba(0,0,0,0.1)' }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Typography variant="body2" color="text.secondary">
                        {items.length} items
                      </Typography>
                      <Typography variant="body2" fontWeight={600} color="red">
                        Total: Rs {items.reduce((sum, item) => sum + item.price, 0)}
                      </Typography>
                    </Box>
                  </Box>
                )} */}
              </CardContent>
            </Card>
          
        ))}
      </Box>

      {/* Summary Section */}
      {/* <Box sx={{ mt: 6, p: 4, borderRadius: 4, background: 'linear-gradient(135deg, #f8fafc 0%, #e3e9f6 100%)' }}>
        <Typography variant="h5" fontWeight={600} sx={{ mb: 3, color: '#1976d2' }}>
          Weekly Summary
        </Typography>
        <Grid container spacing={3}>
          <Grid item xs={12} sm={4}>
            <Box sx={{ textAlign: 'center', p: 2 }}>
              <Typography variant="h4" fontWeight={700} color="primary">
                {weekMenu.filter(day => day.hasMenu).length}
              </Typography>
              <Typography variant="body1" color="text.secondary">
                Days with Menu
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={12} sm={4}>
            <Box sx={{ textAlign: 'center', p: 2 }}>
              <Typography variant="h4" fontWeight={700} color="primary">
                {weekMenu.reduce((total, day) => total + (day.items?.length || 0), 0)}
              </Typography>
              <Typography variant="body1" color="text.secondary">
                Total Items
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={12} sm={4}>
            <Box sx={{ textAlign: 'center', p: 2 }}>
              <Typography variant="h4" fontWeight={700} color="primary">
              Est. {weeklyMin}-{weeklyMax}/-
              </Typography>
              <Typography variant="body1" color="text.secondary">
                Total Value
              </Typography>
            </Box>
          </Grid>
        </Grid>
      </Box> */}
    </Container>
  );
};

export default AdminViewMenu;