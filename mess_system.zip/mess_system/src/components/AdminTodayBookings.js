import React, { useEffect, useState, useMemo, useRef } from 'react';
import { 
  Box, 
  Typography, 
  Paper, 
  CircularProgress, 
  Alert, 
  Stack, 
  TextField, 
  Button, 
  Switch, 
  FormControlLabel, 
  Container, 
  Grid, 
  Chip, 
  InputAdornment,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions
} from '@mui/material';
import axios from 'axios';
import RestaurantIcon from '@mui/icons-material/Restaurant';
import CalendarTodayIcon from '@mui/icons-material/CalendarToday';
import SearchIcon from '@mui/icons-material/Search';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import CancelIcon from '@mui/icons-material/Cancel';
import PersonOutlineIcon from '@mui/icons-material/PersonOutline';
import AttachMoneyIcon from '@mui/icons-material/AttachMoney';
import { AgGridReact } from 'ag-grid-react';
import { ModuleRegistry, AllCommunityModule } from 'ag-grid-community';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import './Admin.css';

ModuleRegistry.registerModules([AllCommunityModule]);

const AdminTodayBookings = () => {
  const [bookings, setBookings] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [attendance, setAttendance] = useState({});
  const [saving, setSaving] = useState(false);
  const [attendanceMarked, setAttendanceMarked] = useState({});
  const [dailyCost, setDailyCost] = useState(null);
  const [showCostDialog, setShowCostDialog] = useState(false);
  const [totalCost, setTotalCost] = useState('');
  const [savingCost, setSavingCost] = useState(false);

  const gridRef = useRef(null);

  const today = new Date();
  const todayStr = today.toISOString().split('T')[0];
  const dayOfWeek = today.toLocaleDateString('en-US', { weekday: 'long' });

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      setError('');
      setSuccess('');
      try {
        // Fetch bookings
        const bookingsRes = await axios.get(`/api/admin/bookings/${todayStr}`, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${localStorage.getItem('adminToken')}`
          }
        });

        // Fetch daily cost
        const costRes = await axios.get(`/api/admin/daily-cost/${todayStr}`, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${localStorage.getItem('adminToken')}`
          }
        });

        setBookings(bookingsRes.data.bookings || []);
        setFiltered(bookingsRes.data.bookings || []);
        setDailyCost(costRes.data.dailyCost);

        const att = {};
        const marked = {};
        (bookingsRes.data.bookings || []).forEach(b => {
          att[b._id] = b.present || false;
          marked[b._id] = b.present !== null;
        });
        setAttendance(att);
        setAttendanceMarked(marked);
      } catch (err) {
        setError(err.response?.data?.message || 'Failed to fetch data');
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [todayStr]);

  useEffect(() => {
    if (!search) {
      setFiltered(bookings);
    } else {
      setFiltered(bookings.filter(b => b.username?.toLowerCase().includes(search.toLowerCase())));
    }
  }, [search, bookings]);

  const handleAttendanceChange = (id, value) => {
    setAttendance(prev => ({ ...prev, [id]: value }));
  };

  const handleSaveAttendance = async () => {
    setSaving(true);
    setError('');
    setSuccess('');
    try {
      const attendanceData = filtered.map(b => ({ userId: b.userId, present: attendance[b._id] }));
      await axios.post(`/api/admin/attendance/${todayStr}`, { attendanceData }, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${localStorage.getItem('adminToken')}`
        }
      });
      setSuccess('Attendance updated successfully!');
      
      // Update attendance marked status
      const marked = {};
      filtered.forEach(b => {
        marked[b._id] = true;
      });
      setAttendanceMarked(marked);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to update attendance');
    } finally {
      setSaving(false);
    }
  };

  const handleSaveDailyCost = async () => {
    if (!totalCost || totalCost <= 0) {
      setError('Please enter a valid total cost');
      return;
    }

    setSavingCost(true);
    setError('');
    try {
      const res = await axios.post(`/api/admin/daily-cost/${todayStr}`, { totalCost: Number(totalCost) }, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${localStorage.getItem('adminToken')}`
        }
      });
      
      setDailyCost(res.data.dailyCost);
      setShowCostDialog(false);
      setTotalCost('');
      setSuccess('Daily cost updated successfully!');
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to update daily cost');
    } finally {
      setSavingCost(false);
    }
  };

  // AG Grid column definitions
  const columnDefs = useMemo(() => [
    {
      headerName: '#',
      valueGetter: params => params.node ? params.node.rowIndex + 1 : '',
      width: 60,
      pinned: 'left',
      cellStyle: { textAlign: 'center', fontWeight: 600 },
      editable: false
    },
    {
      headerName: 'User',
      field: 'username',
      flex:1.5,
      cellRenderer: params => (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <PersonOutlineIcon sx={{ color: '#1976d2', fontSize: 18 }} />
          <span>{params.value}</span>
        </Box>
      ),
      editable: false
    },
    {
      headerName: 'Choice',
      field: 'choice',
     flex:1,
      cellRenderer: params => (
        <Chip
          label={params.value}
          color={params.value === 'accept' ? 'success' : 'default'}
          variant="outlined"
          size="small"
          sx={{ fontWeight: 600 }}
        />
      ),
      editable: false
    },
    {
      headerName: 'Attendance',
      field: 'attendance',
      flex:1,
      cellRenderer: params => {
        const booking = params.data;
        if (booking.choice !== 'accept') {
          return <Chip label="Not Attending" color="default" variant="outlined" size="small" />;
        }
        
        if (attendanceMarked[booking._id]) {
          return (
            <Chip
              label={attendance[booking._id] ? 'Present (Marked)' : 'Absent (Marked)'}
              color={attendance[booking._id] ? 'success' : 'default'}
              variant="filled"
              size="small"
              sx={{ fontWeight: 600 }}
            />
          );
        }
        
        return (
          <FormControlLabel
            control={
              <Switch
                checked={!!attendance[booking._id]}
                onChange={e => handleAttendanceChange(booking._id, e.target.checked)}
                size="small"
                sx={{
                  '& .MuiSwitch-thumb': { 
                    background: attendance[booking._id] ? '#1976d2' : '#bdbdbd' 
                  },
                  '& .MuiSwitch-track': { 
                    background: attendance[booking._id] ? '#e3f2fd' : '#eee' 
                  },
                }}
              />
            }
            label={
              <Typography variant="body2" fontWeight={600} sx={{ 
                color: attendance[booking._id] ? '#1976d2' : '#d32f2f',
                fontSize: '0.75rem'
              }}>
                {attendance[booking._id] ? 'Present' : 'Absent'}
              </Typography>
            }
            sx={{ margin: 0 }}
          />
        );
      },
      editable: false
    },
    {
      headerName: 'Amount',
      field: 'amount',
      flex:1.1,
      cellRenderer: params => {
        const booking = params.data;
        if (booking.choice !== 'accept' || !dailyCost) {
          return '-';
        }
        return (
          <Chip
            label={`Rs ${dailyCost.costPerPerson || 0}`}
            color="primary"
            variant="outlined"
            size="small"
            icon={<AttachMoneyIcon />}
            sx={{ fontWeight: 600 }}
          />
        );
      },
      editable: false
    }
  ], [attendance, attendanceMarked, dailyCost]);

  const defaultColDef = useMemo(() => ({
    resizable: true,
    sortable: true,
    filter: true
  }), []);

  // Dynamic grid height to avoid large blank area when few/no rows
  const rowHeightPx = 50;
  const headerHeightPx = 40;
  const pagerHeightPx = 56; // approx height of pagination footer
  const minGridHeightPx = 240;
  const maxGridHeightPx = 500;
  const visibleRows = Math.max(filtered.length, 1);
  const gridHeight = Math.min(
    maxGridHeightPx,
    Math.max(minGridHeightPx, headerHeightPx + visibleRows * rowHeightPx + pagerHeightPx)
  );

  if (loading) return (
    <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '50vh' }}>
      <CircularProgress size={60} />
    </Box>
  );

  const total = filtered.length;
  const accepted = filtered.filter(b => b.choice === 'accept').length;
  const denied = filtered.filter(b => b.choice === 'deny').length;

  return (
    <Container maxWidth="lg" sx={{ pt: 0.1, pb: 0 }}>
      {/* Header: Title + Summary aligned */}
      <Grid container justifyContent= 'space-between' alignItems="center" sx={{ mb: 2 }}>
        <Grid item xs={12} md={7} lg={8}>
          <Paper elevation={0} sx={{ p: 2, display: 'flex', flexDirection: 'column', gap: 1 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.25 }}>
              <RestaurantIcon sx={{ color: '#1976d2' }} />
              <Typography variant="h6" fontWeight={700} sx={{ color: '#1976d2' }}>
                Today's Bookings
              </Typography>
              <Stack direction="row" spacing={1}>
              <Chip icon={<CalendarTodayIcon />} label={`Total: ${total}`} color="primary" variant="outlined" size="small" />
              <Chip icon={<CheckCircleIcon />} label={`Accepted: ${accepted}`} color="success" variant="outlined" size="small" />
              <Chip icon={<CancelIcon />} label={`Denied: ${denied}`} color="default" variant="outlined" size="small" />
            </Stack>  
            </Box>
            
            
            
            
          </Paper>
        </Grid>
        <Grid item xs={12} md={5} lg={4} >
          {/* Daily Cost Summary */}
          <Box sx={{ display: 'flex', justifyContent: { xs: 'flex-start', md: 'flex-end' } }}>
            <Paper elevation={3} sx={{ p: 0.5, minWidth: 260, maxWidth: 340 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
                <Typography variant="subtitle1" fontWeight={700} color="primary">
                  Daily Cost
                </Typography>
                <Button
                  variant="outlined"
                  size="small"
                  onClick={() => setShowCostDialog(true)}
                  startIcon={<AttachMoneyIcon />}
                >
                  {dailyCost ? 'Edit' : 'Set'}
                </Button>
              </Box>
              {dailyCost ? (
                <Grid container spacing={1}>
                  <Grid item xs={6}>
                    <Typography variant="caption" color="text.secondary">Total:

                    Rs {dailyCost.totalCost}

                    </Typography>
                    <Typography variant="subtitle1" fontWeight={700} color="success.main">
                    </Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="caption" color="text.secondary">Per Person

                      Rs {dailyCost.costPerPerson}
                    </Typography>
                    <Typography variant="subtitle1" fontWeight={700} color="primary.main">
                    </Typography>
                  </Grid>
                </Grid>
              ) : (
                <Typography variant="body2" color="text.secondary">
                  No daily cost set.
                </Typography>
              )}
            </Paper>
          </Box>
        </Grid>
      </Grid>

      {/* Controls */}
      <Grid container justifyContent= 'space-between' sx={{ mb: 2 }}>
        <Grid item xs={12} md={6} lg={5}>
          <TextField
            label="Search user"
            value={search}
            onChange={e => setSearch(e.target.value)}
            fullWidth
            size="small"
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon sx={{ color: '#1976d2' }} />
                </InputAdornment>
              )
            }}
          />
        </Grid>
        <Button
          variant="contained"
          color="primary"
          sx={{
            fontWeight: 700,
            fontSize: 17,
            px: 5,
            py: 1.25,
            borderRadius: 3,
            boxShadow: '0 4px 16px rgba(25,118,210,0.13)',
            textTransform: 'none',
            transition: 'background 0.2s, box-shadow 0.2s',
            background: saving ? '#bdbdbd' : '#1976d2',
            '&:hover': {
              background: saving ? '#bdbdbd' : '#1565c0',
              boxShadow: '0 8px 32px rgba(25,118,210,0.22)',
            },
          }}
          onClick={handleSaveAttendance}
          disabled={saving || Object.values(attendanceMarked).every(marked => marked)}
        >
          {saving ? 'Saving...' : Object.values(attendanceMarked).every(marked => marked) ? 'Attendance Submitted' : 'Save Attendance'}
        </Button>
      </Grid>

      {error && (
        <Alert severity="error" sx={{ mb: 2, borderRadius: 2, fontSize: 15 }}>
          {error}
        </Alert>
      )}
      {success && (
        <Alert severity="success" sx={{ mb: 2, borderRadius: 2, fontSize: 15 }}>
          {success}
        </Alert>
      )}

      {/* Bookings Table */}
      <Paper elevation={8} sx={{ borderRadius: 3, mb: 1, p: 2 }}>
        <div className="ag-theme-alpine" style={{ width: '100%', height: '55vh' }}>
          <AgGridReact
            ref={gridRef}
            rowData={filtered}
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}
            headerHeight={40}
            rowHeight={50}
             theme="legacy"
            pagination
            paginationPageSize={10}
            paginationPageSizeSelector={[10, 20, 50]}
            overlayNoRowsTemplate={'<span style="padding: 10px; display: inline-block;">No bookings found</span>'}
            quickFilterText={search}
          />
        </div>
      </Paper>

      {/* Action Buttons */}
      {/* <Box sx={{ display: 'flex', gap: 2, justifyContent: 'center' }}>
        
      </Box> */}

      {/* Daily Cost Dialog */}
      <Dialog open={showCostDialog} onClose={() => setShowCostDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <AttachMoneyIcon color="primary" />
            Set Daily Cost for {dayOfWeek}
          </Box>
        </DialogTitle>
        <DialogContent>
          <Box sx={{ mt: 2 }}>
            <TextField
              label="Total Cost for Today (Rs)"
              type="number"
              value={totalCost}
              onChange={(e) => setTotalCost(e.target.value)}
              fullWidth
              placeholder="Enter total cost for today's meals"
              InputProps={{
                startAdornment: <InputAdornment position="start">Rs</InputAdornment>,
              }}
            />
            {dailyCost && (
              <Box sx={{ mt: 2, p: 2, bgcolor: 'grey.50', borderRadius: 1 }}>
                <Typography variant="body2" color="text.secondary">
                  Current accepted bookings: <strong>{accepted}</strong>
                </Typography>
                {accepted > 0 && totalCost > 0 && (
                  <Typography variant="body2" color="text.secondary">
                    Cost per person will be: <strong>Rs {Math.round(Number(totalCost) / accepted)}</strong>
                  </Typography>
                )}
              </Box>
            )}
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setShowCostDialog(false)}>Cancel</Button>
          <Button 
            onClick={handleSaveDailyCost} 
            variant="contained" 
            disabled={savingCost || !totalCost || totalCost <= 0}
          >
            {savingCost ? 'Saving...' : 'Save Cost'}
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default AdminTodayBookings;