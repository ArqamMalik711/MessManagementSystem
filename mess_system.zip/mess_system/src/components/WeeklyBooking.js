import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Typography, 
  Paper, 
  Button, 
  Stack, 
  Alert, 
  CircularProgress,
  Container,
  Grid,
  Card,
  CardContent,
  Chip,
  Divider,
  IconButton,
  Tooltip
} from '@mui/material';
import {
  Restaurant as RestaurantIcon,
  CalendarToday as CalendarIcon,
  Today as TodayIcon,
  CheckCircle as CheckCircleIcon,
  Cancel as CancelIcon,
  HourglassEmpty as PendingIcon,
  ExpandMore as ExpandMoreIcon,
  ExpandLess as ExpandLessIcon,
  Lock as LockIcon
} from '@mui/icons-material';
import axios from 'axios';

const weekdays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

const WeeklyBooking = () => {
  const [menu, setMenu] = useState([]);
  const [choices, setChoices] = useState({});
  const [expanded, setExpanded] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');
  const [currentWeek, setCurrentWeek] = useState(null);
  const [currentYear, setCurrentYear] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      setError('');
      setInfo('');
      
      try {
        const menuRes = await axios.get('/api/user/menu/current-week', {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${localStorage.getItem('userToken')}`
          }
        });
        console.log('Menu response:', menuRes.data); // Debug log
        setMenu(menuRes.data.weekMenu || []);
        setCurrentWeek(menuRes.data.currentWeek);
        setCurrentYear(menuRes.data.currentYear);

        const bookingRes = await axios.get('/api/user/bookings/history', {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${localStorage.getItem('userToken')}`
          }
        });
        const bookings = bookingRes.data.bookings || [];
        const weekBookings = bookings.filter(
          b =>
            b.weekNumber === menuRes.data.currentWeek &&
            b.year === menuRes.data.currentYear &&
            b.month === new Date().getMonth()
        );
        
        // Always load existing choices, regardless of how many days have choices
        if (weekBookings.length > 0) {
          const mapped = {};
          weekBookings.forEach(d => {
            mapped[d.dayOfWeek] = d.choice?.toLowerCase();
          });
          setChoices(mapped);
          setSubmitted(false); // Allow editing
          setInfo(`You have ${weekBookings.length} day(s) with choices. You can edit them anytime during the week.`);
        } else {
          setChoices({});
          setSubmitted(false);
          setInfo('No choices made yet. Make your selections for the week.');
        }
      } catch (err) {
        setError(err.response?.data?.message || 'Failed to fetch menu/booking');
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const handleChoice = (day, value) => {
    setChoices(prev => ({ ...prev, [day]: value }));
  };

  const handleSubmit = async () => {
    setError('');
    setInfo('');

    // Only check unlocked days for validation
    const unlockedDays = weekdays.filter(day => {
      const dayData = menu.find(m => m.dayOfWeek === day);
      return dayData && !dayData.isLocked;
    });

    for (let day of unlockedDays) {
      if (!choices[day]) {
        setError(`Please select accept/deny for ${day}`);
        return;
      }
    }

    setLoading(true);
    try {
      // Only send choices for unlocked days
      const menuData = menu
        .filter(({ isLocked }) => !isLocked)
        .map(({ date, dayOfWeek }) => ({
          date,
          choice: choices[dayOfWeek]
        }));

      await axios.post(
        '/api/user/booking/weekly',
        {
          week: currentWeek,
          menu: menuData
        },
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${localStorage.getItem('userToken')}`
          }
        }
      );

      setSubmitted(true);
      setInfo('Your choices have been submitted!');
    } catch (err) {
      setError(err.response?.data?.message || 'Submission failed');
    } finally {
      setLoading(false);
    }
  };

  const isToday = (date) => new Date(date).toDateString() === new Date().toDateString();
  const dayColor = '#2e7d32';

  const summary = () => {
    const total = menu.length || 0;
    let accepted = 0, denied = 0;
    Object.values(choices).forEach(v => {
      if (v === 'accept') accepted += 1;
      else if (v === 'deny') denied += 1;
    });
    const pending = Math.max(0, total - accepted - denied);
    return { total, accepted, denied, pending };
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="60vh">
        <CircularProgress size={60} sx={{ color: '#2e7d32' }} />
      </Box>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ pt: 2, pb: 0 }}>
      {/* Header */}
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.25 }}>
          <RestaurantIcon sx={{ color: '#2e7d32' }} />
          <Typography variant="h6" fontWeight={700} sx={{ color: '#1b5e20' }}>
            Weekly Menu Booking
          </Typography>
        </Box>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}
      {info && (
        <Alert severity="info" sx={{ mb: 2 }}>
          {info}
        </Alert>
      )}

      {/* Day Cards */}
      <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 1.5 }}>
        {menu.map(({ date, dayOfWeek, items, isLocked }) => {
          const choice = choices[dayOfWeek];
          const isAccepted = choice === 'accept';
          const isDenied = choice === 'deny';
          const todayFlag = isToday(date);
          const isExpanded = !!expanded[dayOfWeek];
          const handleToggleExpand = () => setExpanded(prev => ({ ...prev, [dayOfWeek]: !prev[dayOfWeek] }));
          return (
            <Box key={dayOfWeek} sx={{ display: 'flex' }}>
              <Card
                elevation={8}
                sx={{
                  width: '100%',
                  height: 300,
                  minHeight: 240,
                  display: 'flex',
                  flexDirection: 'column',
                  borderRadius: 2,
                  background: isLocked ? 'linear-gradient(135deg, #f5f5f5 0%, #e0e0e0 100%)' : 'linear-gradient(135deg, #ffffff 0%, #f8fafc 100%)',
                  border  : isLocked ? "2px solid #bdbdbd" :isAccepted ? "2px solid rgba(46,125,50,0.8)" :isDenied? "2px solid rgba(211,47,47,0.8)" : "2px solid transparent",
                  transition: 'all 0.3s ease',
                  position: 'relative',
                  overflow: 'hidden',
                  opacity: isLocked ? 0.7 : 1,
                  '&:hover': {
                    transform: isLocked ? 'none' : 'translateY(-4px)',
                    // boxShadow: isLocked ? '0 4px 20px rgba(0,0,0,0.08)' : '0 12px 24px rgba(46,125,50,0.18)',
                    // borderColor: isLocked ? '#bdbdbd' : 'rgba(46,125,50,0.4)',
                  },
                  // '&::before': {
                  //   content: '""',
                  //   position: 'absolute',
                  //   top: 0,
                  //   left: 0,
                  //   right: 0,
                  //   height: 3,
                  //   background: isLocked ? 'linear-gradient(90deg, #bdbdbd, #9e9e9e)' : 'linear-gradient(90deg, #2e7d32, #1b5e20)',
                  //   borderTopLeftRadius: 'inherit',
                  //   borderTopRightRadius: 'inherit'
                  // }
                }}
              >
                <CardContent sx={{ p: 2, height: '100%', display: 'flex', flexDirection: 'column', flex: 1 }}>
                  {/* Header */}
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: -2 }}>
                    <Box sx={{ flex: 1 }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Typography variant="subtitle1" fontWeight={700} sx={{ color: isLocked ? '#757575' : dayColor }}>
                          {dayOfWeek}
                        </Typography>
                        {isLocked && (
                         <Tooltip
                         title="Booking locked - Previous day or today after 10 AM"
                         componentsProps={{
                           tooltip: {
                             sx: {
                               backgroundColor: "#1b5e20", // or #1b5e20 for user
                               color: "#fff",
                               fontSize: "13px",
                             },
                           },
                         }}
                       >
                         <LockIcon fontSize="small" sx={{ color: "#757575" }} />
                       </Tooltip>
                       
                        )}
                      </Box>
                    </Box>
                    <Chip
                      icon={isAccepted ? <CheckCircleIcon /> : isDenied ? <CancelIcon /> : <PendingIcon />}
                      color={isAccepted ? 'success' : isDenied ? 'error' : 'default'}
                      size="small"
                      variant={isAccepted ? 'filled' : 'outlined'}
                      sx={{ fontWeight: 600 }}
                    />
                  </Box>

                  <Divider sx={{ my: 1.5, opacity: 0.3 }} />

                  {/* Items */}
                  <Box sx={{ flex: 1, minHeight: 60, position: 'relative' }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 0.5 }}>
                      <Typography variant="subtitle2" fontWeight={700} sx={{ color: 'text.primary', opacity: 0.8 }}>
                        Items
                      </Typography>
                      {items.length > 3 && (
                        <IconButton size="small" onClick={handleToggleExpand} aria-label={isExpanded ? 'Collapse' : 'Expand'}>
                          {isExpanded ? <ExpandLessIcon fontSize="small" /> : <ExpandMoreIcon fontSize="small" />}
                        </IconButton>
                      )}
                    </Box>
                    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.75, maxHeight: isExpanded ? 120 : 'none', overflowY: isExpanded ? 'auto' : 'visible', pr: isExpanded ? 1 : 0 }}>
                      {(isExpanded ? items : items.slice(0, 3)).map((item, i) => (
                        <Box key={i} sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', p: 1, borderRadius: 2, background: 'rgba(46,125,50,0.05)', border: '1px solid rgba(46,125,50,0.1)' }}>
                          <Typography variant="body2" fontWeight={600}>{item.item}</Typography>
                          <Chip label={`${item.range}/-`} size="small" color="success" variant="outlined" sx={{ fontWeight: 600 }} />
                        </Box>
                      ))}
                    </Box>
                  </Box>

                  {/* Controls - bottom right icon buttons */}
                  <Box sx={{ position: 'absolute', bottom: 10, right: 10, display: 'flex', gap: 1 }}>
                    <Tooltip title="Accept"
                     componentsProps={{
                      tooltip: {
                        sx: {
                          backgroundColor: "#1b5e20", // or #1b5e20 for user
                          color: "#fff",
                          fontSize: "13px",
                        },
                      },
                    }}
                  >
                    <IconButton
                      size="small"
                      color="success"
                      disabled={submitted || isLocked}
                      onClick={() => handleChoice(dayOfWeek, 'accept')}
                      sx={{ 
                        bgcolor: choices[dayOfWeek] === 'accept' ? 'rgba(46,125,50,0.12)' : 'transparent',
                        opacity: isLocked ? 0.5 : 1
                      }}
                    >
                      <CheckCircleIcon fontSize="small" />
                    </IconButton>
                    </Tooltip>
                   
            
                    <Tooltip title="Deny"
                     componentsProps={{
                      tooltip: {
                        sx: {
                          backgroundColor: "#1b5e20", // or #1b5e20 for user
                          color: "#fff",
                          fontSize: "13px",
                        },
                      },
                    }}
                  >
                    <IconButton
                      size="small"
                      color="error"
                      disabled={submitted || isLocked}
                      onClick={() => handleChoice(dayOfWeek, 'deny')}
                      sx={{ 
                        bgcolor: choices[dayOfWeek] === 'deny' ? 'rgba(211,47,47,0.12)' : 'transparent',
                        opacity: isLocked ? 0.5 : 1
                      }}
                    >
                      <CancelIcon fontSize="small" />
                    </IconButton>
                    </Tooltip>
                    
                  </Box>
                </CardContent>
              </Card>
            </Box>
          );
        })}
      </Box>

      {/* Submit */}
      <Button
        variant="contained"
        color="primary"
        sx={{
          mt: 4,
          mb: 4,
          fontWeight: 700,
          fontSize: 15,
          px: 4,
          py: 1.25,
          borderRadius: 2,
          boxShadow: '0 4px 16px 0 rgba(46,125,50,0.13)',
          textTransform: 'none',
          transition: 'background 0.2s, box-shadow 0.2s',
          background: submitted ? '#bdbdbd' : 'linear-gradient(90deg, #2e7d32 70%, #4caf50 100%)',
          '&:hover': {
            background: submitted ? '#bdbdbd' : 'linear-gradient(90deg, #1b5e20 70%, #388e3c 100%)',
            boxShadow: '0 8px 32px 0 rgba(46,125,50,0.22)',
          },
        }}
        onClick={handleSubmit}
        disabled={loading}
      >
        Submit/Update Weekly Choices
      </Button>
    </Container>
  );
};

export default WeeklyBooking;
