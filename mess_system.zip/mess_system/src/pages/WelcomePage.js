import React from "react";
import {
  Box,
  Typography,
  Button,
  Stack,
  Paper,
  Container,
  Grid,
  Chip
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import RestaurantIcon from '@mui/icons-material/Restaurant';
import AdminPanelSettingsIcon from '@mui/icons-material/AdminPanelSettings';
import PersonIcon from '@mui/icons-material/Person';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import SecurityIcon from '@mui/icons-material/Security';

const WelcomePage = () => {
  const navigate = useNavigate();

  return (
    <Box
      sx={{
        height: '100vh',
        background: "linear-gradient(135deg, #1976d2 0%, #2e7d32 50%, #1565c0 100%)",
        position: "relative",
        overflow: "hidden",
        "&::before": {
          content: '""',
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          // background: "url('data:image/svg+xml,<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 100 100\"><defs><pattern id=\"grain\" width=\"100\" height=\"100\" patternUnits=\"userSpaceOnUse\"><circle cx=\"50\" cy=\"50\" r=\"1\" fill=\"rgba(255,255,255,0.1)\"/></pattern></defs><rect width=\"100\" height=\"100\" fill=\"url(%23grain)\"/></svg>')",
          opacity: 0.3,
        }
      }}
    >
      {/* Floating elements */}
      <Box
        sx={{
          position: "absolute",
          top: "8%",
          left: "8%",
          width: 160,
          height: 160,
          borderRadius: "50%",
          background: "rgba(255,255,255,0.1)",
          animation: "float 6s ease-in-out infinite",
          "@keyframes float": {
            "0%, 100%": { transform: "translateY(0px)" },
            "50%": { transform: "translateY(-16px)" }
          }
        }}
      />
      <Box
        sx={{
          position: "absolute",
          top: "60%",
          right: "12%",
          width: 120,
          height: 120,
          borderRadius: "50%",
          background: "rgba(255,255,255,0.08)",
          animation: "float 8s ease-in-out infinite reverse",
        }}
      />

      <Container maxWidth="lg" sx={{ py: { xs: 4, md: 6 }, height: '100%' }}>
        <Grid container spacing={4} alignItems="flex-start" justifyContent="left" height="100%" sx={{ pt: { xs: 6, md: 8 } }}>
          <Grid item xs={12} md={9} lg={8}>
            <Box sx={{ color: "white", mb: 4, textAlign: 'left' }}>
              <Typography
                variant="h2"
                fontWeight={800}
                gutterBottom
                sx={{
                  fontSize: { xs: "2.8rem", md: "4rem" , lg: "5rem"},
                  lineHeight: 1.1,
                  textShadow: "2px 2px 4px rgba(0,0,0,0.3)",
                  mb: 2
                }}
              >
                CARE Mess
                <br />
                <span>Management System</span>
              </Typography>

              <Typography
                variant="h5"
                sx={{
                  mb: 4,
                  opacity: 0.9,
                  fontWeight: 300,
                  lineHeight: 1.35
                }}
              >
                Streamline your mess operations with our comprehensive management system
              </Typography>

              <Stack direction={{ xs: "column", sm: "row" }} spacing={2.5} sx={{  mb: 4 }} justifyContent="center" alignItems="center">
                <Button
                  variant="contained"
                  size="large"
                  startIcon={<PersonIcon />}
                  onClick={() => navigate("/login/user")}
                  sx={{
                    py: 2,
                    px: 6,
                    fontWeight: 600,
                    borderRadius: 3,
                    textTransform: "none",
                    fontSize: "1.2rem",
                    background: "linear-gradient(45deg, #2e7d32, #4caf50)",
                    boxShadow: "0 8px 32px rgba(46, 125, 50, 0.3)",
                    "&:hover": {
                      background: "linear-gradient(45deg, #1b5e20, #2e7d32)",
                      transform: "translateY(-2px)",
                      boxShadow: "0 12px 40px rgba(46, 125, 50, 0.4)",
                    },
                    transition: "all 0.3s ease"
                  }}
                >
                  User Login
                </Button>
                <Button
                  variant="contained"
                  size="large"
                  startIcon={<AdminPanelSettingsIcon />}
                  onClick={() => navigate("/login/admin")}
                  sx={{
                    py: 2,
                    px: 6,
                    fontWeight: 600,
                    borderRadius: 3,
                    textTransform: "none",
                    fontSize: "1.2rem",
                    borderColor: "white",
                    color: "white",
                    background: "rgba(26, 68, 185, 0.63)",
                    "&:hover": {
                      // borderColor: "#1976d2",
                      // color: "#1976d2",
                      background: "rgba(13, 51, 155, 0.63)",
                      transform: "translateY(-2px)",
                      
                    },
                    transition: "all 0.3s ease"
                  }}
                >
                  Admin Login
                </Button>
              </Stack>

              
            </Box>
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
};

export default WelcomePage;
