import React, { useEffect, useState } from 'react';
import { 
  Box, 
  Typography, 
  Drawer, 
  List, 
  ListItem, 
  ListItemIcon, 
  ListItemText, 
  AppBar, 
  Toolbar, 
  IconButton,
  Avatar,
  Divider,
  Badge,
  Tooltip
} from '@mui/material';
import CalendarTodayIcon from '@mui/icons-material/CalendarToday';
import ReceiptIcon from '@mui/icons-material/Receipt';
import RestaurantMenuIcon from '@mui/icons-material/RestaurantMenu';
import LockIcon from '@mui/icons-material/Lock';
import MenuIcon from '@mui/icons-material/Menu';
import GroupIcon from '@mui/icons-material/Group';
import PersonAddIcon from '@mui/icons-material/PersonAdd';
import DashboardIcon from '@mui/icons-material/Dashboard';
import NotificationsIcon from '@mui/icons-material/Notifications';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import LogoutIcon from '@mui/icons-material/Logout';
import AdminPanelSettingsIcon from '@mui/icons-material/AdminPanelSettings';
import AdminCreateMenu from '../components/AdminCreateMenu';
import AdminViewMenu from '../components/AdminViewMenu';
import AdminUserBills from '../components/AdminUserBills';
import AdminTodayBookings from '../components/AdminTodayBookings';
import AdminChangePassword from '../components/AdminChangePassword';
import AdminCreateUser from '../components/AdminCreateUser';
import AdminItemsList from '../components/AdminItemsList';
import { useNavigate } from 'react-router-dom';

const drawerWidth = 280;

const menuItems = [
  { 
    text: 'Create Menu', 
    icon: <RestaurantMenuIcon />, 
    // description: 'Create and manage weekly menus',
    color: '#1976d2'
  },
  
  { 
    text: 'User Bookings for Today', 
    icon: <GroupIcon />, 
    // description: 'Mark attendance for today',
    color: '#ed6c02'
  },
  { 
    text: 'View All User Bills', 
    icon: <ReceiptIcon />, 
    // description: 'Manage user bills and payments',
    color: '#9c27b0'
  },
  {
    text: 'Items List',
    icon: <RestaurantMenuIcon />,
    color: '#1976d2'
  },
  
  { 
    text: 'Create User', 
    icon: <PersonAddIcon />, 
    // description: 'Add new users to the system',
    color: '#1976d2'
  },
  { 
    text: 'Change Password', 
    icon: <LockIcon />, 
    // description: 'Update your password',
    color: '#d32f2f'
  },
  
];

const AdminDashboard = () => {
  const [selected, setSelected] = useState(0); // Changed default to 1 (View Menu)
  const [mobileOpen, setMobileOpen] = useState(false);
  const [serverDate, setServerDate] = useState('');
  const [serverTime, setServerTime] = useState('');
  // Fetch server time/date and refresh periodically
  useEffect(() => {
    let timerId;
    const fetchTime = async () => {
      try {
        const res = await fetch('/api/time/now');
        const data = await res.json();
        setServerDate(data.dateString || '');
        setServerTime(data.timeString || '');
      } catch (e) {
        const now = new Date();
        setServerDate(now.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }));
        setServerTime(now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }));
      }
    };
    fetchTime();
    timerId = setInterval(fetchTime, 60_000);
    return () => clearInterval(timerId);
  }, []);
  const navigate = useNavigate();

  const handleDrawerToggle = () => setMobileOpen(!mobileOpen);

  const handleLogout = () => {
    localStorage.removeItem('adminToken');
    navigate('/');
  };

  const renderContent = () => {
    switch (selected) {
      case 0:
        return <AdminCreateMenu />;
      case 1:
        return <AdminTodayBookings />;
      case 2:
        return <AdminUserBills />;
      case 3:
        return <AdminItemsList />;
      case 4:
        return <AdminCreateUser />;
      case 5:
        return <AdminChangePassword />;

      default:
        return null;
    }
  };

  const drawer = (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      {/* Header */}
      <Box
        sx={{
          p: 3,
          background: 'linear-gradient(135deg, #1976d2 0%, #1565c0 100%)',
          color: 'white',
          textAlign: 'center',
          mt: 8 // Add margin top to account for the AppBar height
        }}
      >
        <Avatar
          sx={{
            width: 60,
            height: 60,
            mx: 'auto',
            mb: 2,
            background: 'rgba(255,255,255,0.2)',
            fontSize: '1.5rem'
          }}
        >
          <AdminPanelSettingsIcon />
        </Avatar>
        <Typography variant="h6" fontWeight={600} gutterBottom>
          Admin Dashboard
        </Typography>
        <Typography variant="body2" sx={{ opacity: 0.8 }}>
          
        </Typography>
      </Box>

      <Divider />

      {/* Navigation */}
      <List sx={{ flex: 1, p: 2 }}>
        {menuItems.map((item, idx) => (
          <ListItem
            button
            key={item.text}
            selected={selected === idx}
            onClick={() => setSelected(idx)}
            sx={{
              background: selected === idx ? 'rgba(33, 112, 192, 0.22)' : 'white',
              mb: 1,
              borderRadius: 2,
              transition: 'all 0.3s ease',
              '&:hover': {
                background: 'rgba(25, 118, 210, 0.08)',
                transform: 'translateX(4px)',
              },
              '&.Mui-selected': {
                background: 'linear-gradient(45deg, #1976d2, #42a5f5)',
                color: 'white',
                boxShadow: '0 4px 16px rgba(25, 118, 210, 0.3)',
                '&:hover': {
                  background: 'linear-gradient(45deg, #1565c0, #1976d2)',
                },
                '& .MuiListItemIcon-root': {
                  color: 'white',
                },
                '& .MuiListItemText-secondary': {
                  color: 'rgba(255,255,255,0.8)',
                }
              }
            }}
          >
            <ListItemIcon
              sx={{
                color: item.color,
                minWidth: 40,
                transition: 'all 0.3s ease'
              }}
            >
              {item.icon}
            </ListItemIcon>
            <ListItemText
              primary={item.text}
              secondary={item.description}
              primaryTypographyProps={{
                fontWeight: selected === idx ? 600 : 500,
                fontSize: '0.95rem'
              }}
              secondaryTypographyProps={{
                fontSize: '0.8rem',
                color: selected === idx ? 'rgba(0, 0, 0, 0.8)' : 'text.secondary'
              }}
            />
          </ListItem>
        ))}
      </List>

      <Divider />

      {/* Footer */}
      <Box sx={{ p: 2 }}>
        <Tooltip title="Logout"
         componentsProps={{
          tooltip: {
            sx: {
              backgroundColor: "#1976d2", // or #1b5e20 for user
              color: "#fff",
              fontSize: "13px",
            },
          },
        }}
      >
          <ListItem
            button
            onClick={handleLogout}
            sx={{
              borderRadius: 2,
              color: '#d32f2f',
              '&:hover': {
                background: 'rgba(211, 47, 47, 0.08)',
              }
            }}
          >
            <ListItemIcon sx={{ color: '#d32f2f', minWidth: 40 }}>
              <LogoutIcon />
            </ListItemIcon>
            <ListItemText 
              primary="Logout"
              primaryTypographyProps={{ fontWeight: 500 }}
            />
          </ListItem>
        </Tooltip>
      </Box>
    </Box>
  );

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh', background: '#f8fafc' }}>
      <AppBar
        position="fixed"
        sx={{
          zIndex: (theme) => theme.zIndex.drawer + 1,
          background: 'linear-gradient(90deg, #1976d2 0%, #1565c0 100%)',
          boxShadow: '0 4px 20px rgba(0,0,0,0.1)',
          backdropFilter: 'blur(10px)',
        }}
      >
        <Toolbar sx={{ display: "flex", justifyContent: "space-between", px: 3 }}>
          {/* Left side: Menu + Title */}
          <Box display="flex" alignItems="center">
            <IconButton
              color="inherit"
              edge="start"
              onClick={handleDrawerToggle}
              sx={{ 
                mr: 2, 
                display: { sm: "none" },
                '&:hover': { background: 'rgba(255,255,255,0.1)' }
              }}
            >
              <MenuIcon />
            </IconButton>

            <Box display="flex" alignItems="center">
              <DashboardIcon sx={{ mr: 1, fontSize: 28 }} />
              <Typography
                variant="h6"
                noWrap
                sx={{
                  fontWeight: 700,
                  letterSpacing: 0.5,
                  fontSize: '1.25rem'
                }}
              >
                CARE Mess Management
              </Typography>
              <Typography
                variant="body2"
                sx={{
                  ml: 1,
                  fontWeight: 500,
                  opacity: 0.8,
                  fontSize: "0.85rem",
                  background: 'rgba(255,255,255,0.2)',
                  px: 1.5,
                  py: 0.5,
                  borderRadius: 1,
                }}
              >
                Admin Panel
              </Typography>
            </Box>
          </Box>

          {/* Right side: Date + Time */}
          <Box display="flex" alignItems="center" gap={2}>
            <Box
              sx={{
                display: { xs: 'none', md: 'flex' },
                alignItems: 'center',
                gap: 2,
                background: 'rgba(255,255,255,0.1)',
                px: 2,
                py: 1,
                borderRadius: 2,
              }}
            >
              <Typography
                variant="body2"
                sx={{
                  fontWeight: 500,
                  fontSize: "0.85rem",
                }}
              >
                {serverDate}
              </Typography>
              <Typography
                variant="body2"
                sx={{
                  fontWeight: 600,
                  fontSize: "0.9rem",
                  color: '#ffd700'
                }}
              >
                {serverTime}
              </Typography>
            </Box>
          </Box>
        </Toolbar>
      </AppBar>

      <Box component="nav" sx={{ width: { sm: drawerWidth }, flexShrink: { sm: 0 } }}>
        <Drawer
          variant="temporary"
          open={mobileOpen}
          onClose={handleDrawerToggle}
          ModalProps={{ keepMounted: true }}
          sx={{ 
            display: { xs: 'block', sm: 'none' }, 
            '& .MuiDrawer-paper': { 
              boxSizing: 'border-box', 
              width: drawerWidth,
              border: 'none',
              boxShadow: '4px 0 20px rgba(0,0,0,0.1)'
            } 
          }}
        >
          {drawer}
        </Drawer>
        <Drawer
          variant="permanent"
          sx={{ 
            display: { xs: 'none', sm: 'block' }, 
            '& .MuiDrawer-paper': { 
              boxSizing: 'border-box', 
              width: drawerWidth,
              border: 'none',
              boxShadow: '4px 0 20px rgba(0,0,0,0.1)',
              background: 'white',
              top: 0,
              height: '100vh',
              position: 'fixed'
            } 
          }}
          open
        >
          {drawer}
        </Drawer>
      </Box>

      <Box 
        component="main" 
        sx={{ 
          flexGrow: 1, 
          p: { xs: 2, md: 4 }, 
          mt: 8,
          background: '#f8fafc',
          // minHeight: 'calc(100vh - 64px)'
        }}
      >
        <Box
          sx={{
            background: 'white',
            borderRadius: 3,
            height: '100%',
            boxShadow: '0 4px 20px rgba(0,0,0,0.08)',
            overflow: 'hidden',
            // minHeight: 'calc(100vh - 120px)'
          }}
        >
          {renderContent()}
        </Box>
      </Box>
    </Box>
  );
};

export default AdminDashboard;