const express = require('express');

const router = express.Router();

// Return current server time/date in multiple convenient formats
router.get('/now', (req, res) => {
  const now = new Date();

  const dateString = now.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  const timeString = now.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit'
  });

  res.json({
    iso: now.toISOString(),
    epochMs: now.getTime(),
    dateString,
    timeString,
    weekday: now.toLocaleDateString('en-US', { weekday: 'long' }),
    year: now.getFullYear(),
    month: now.toLocaleString('en-US', { month: 'long' }),
    day: now.getDate()
  });
});

module.exports = router;


