const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const Admin = require('../models/Admin');
const Menu = require('../models/Menu');
const Booking = require('../models/Booking');
const Bill = require('../models/Bill');
const ItemsList = require('../models/ItemsList');
const DailyCost = require('../models/DailyCost');
const { adminAuth } = require('../middleware/auth');
const { getWeekDates, getDayName, getCurrentWeekNumber, getMonthName } = require('../utils/dateUtils');

const router = express.Router();

// Get current week menu
router.get('/menu/current-week', adminAuth, async (req, res) => {
    try {
        const weekDates = getWeekDates();
        const currentWeek = getCurrentWeekNumber();
        const currentMonth = new Date().getMonth();
        const currentYear = new Date().getFullYear();

        const menu = await Menu.find({
            weekNumber: currentWeek,
            month: currentMonth,
            year: currentYear
        }).sort({ date: 1 });

        const weekMenu = weekDates.map(date => {
            const dayMenu = menu.find(m =>
                m.date.toDateString() === date.toDateString()
            );
            return {
                date: date,
                dayOfWeek: getDayName(date),
                items: dayMenu ? dayMenu.items : [],
                hasMenu: !!dayMenu
            };
        });

        res.json({
            weekMenu,
            currentWeek,
            currentMonth: getMonthName(currentMonth),
            currentYear
        });
    } catch (error) {
        console.error('Get current week menu error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Create/Update menu for a specific day
router.post('/menu/:date', adminAuth, async (req, res) => {
    console.log("Reached menu creation route for date:", req.params.date);
    try {
        const { date } = req.params;
        const { items } = req.body;

        if (!items || !Array.isArray(items)) {
            return res.status(400).json({ message: 'Items array is required' });
        }

        const menuDate = new Date(date);
        const dayOfWeek = getDayName(menuDate);
        const weekNumber = getCurrentWeekNumber();
        const month = menuDate.getMonth();
        const year = menuDate.getFullYear();

        // Validate day is Monday to Friday
        if (!['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'].includes(dayOfWeek)) {
            return res.status(400).json({ message: 'Menu can only be created for weekdays' });
        }

        // Validate items
        for (let item of items) {
            if (!item.item || !item.range) {
                return res.status(400).json({ message: 'Each item must have name and range' });
            }
        }

        const menuData = {
            date: menuDate,
            dayOfWeek,
            items,
            weekNumber,
            month,
            year
        };

        // Match menu for the same calendar day
        const startOfDay = new Date(menuDate);
        startOfDay.setHours(0, 0, 0, 0);
        const endOfDay = new Date(menuDate);
        endOfDay.setHours(23, 59, 59, 999);

        const existingMenu = await Menu.findOne({
            date: { $gte: startOfDay, $lte: endOfDay }
        });

        let menu;
        if (existingMenu) {
            menu = await Menu.findOneAndUpdate(
                { _id: existingMenu._id },
                menuData,
                { new: true }
            );
        } else {
            menu = new Menu(menuData);
            await menu.save();
        }

        res.json({
            message: 'Menu updated successfully',
            menu
        });
    } catch (error) {
        console.error('Create/Update menu error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Delete menu for a specific day
router.delete('/menu/:date', adminAuth, async (req, res) => {
    try {
        const { date } = req.params;
        const menuDate = new Date(date);

        const startOfDay = new Date(menuDate);
        startOfDay.setHours(0, 0, 0, 0);
        const endOfDay = new Date(menuDate);
        endOfDay.setHours(23, 59, 59, 999);

        const deletedMenu = await Menu.findOneAndDelete({
            date: { $gte: startOfDay, $lte: endOfDay }
        });

        if (!deletedMenu) {
            return res.status(404).json({ message: 'Menu not found for this date' });
        }

        res.json({ message: 'Menu deleted successfully' });
    } catch (error) {
        console.error('Delete menu error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Get all bills for a month
router.get('/bills/:month/:year', adminAuth, async (req, res) => {
    try {
        const { month, year } = req.params;
        const monthNum = parseInt(month);
        const yearNum = parseInt(year);

        const bills = await Bill.find({
            month: monthNum,
            year: yearNum
        }).sort({ username: 1 });

        // Calculate totals from dailyBreakdown to ensure accuracy
        let totalAmount = 0;
        let totalAcceptedDays = 0;
        let totalDeniedDays = 0;

        bills.forEach(bill => {
            totalAmount += bill.totalAmount || 0;
            
            // Count from dailyBreakdown for accurate totals
            if (bill.dailyBreakdown && Array.isArray(bill.dailyBreakdown)) {
                bill.dailyBreakdown.forEach(day => {
                    if (day.choice === 'accept') {
                        totalAcceptedDays += 1;
                    } else if (day.choice === 'deny') {
                        totalDeniedDays += 1;
                    }
                });
            }
        });

        res.json({
            bills,
            summary: {
                totalAmount,
                totalAcceptedDays,
                totalDeniedDays,
                totalUsers: bills.length
            },
            month: getMonthName(monthNum),
            year: yearNum
        });
    } catch (error) {
        console.error('Get bills error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Get individual user bill for a month
router.get('/user-bill/:userId/:month/:year', adminAuth, async (req, res) => {
    try {
        const { userId, month, year } = req.params;
        const monthNum = parseInt(month);
        const yearNum = parseInt(year);

        console.log('User bill request:', { userId, month, year, monthNum, yearNum });

        // Check if userId is valid ObjectId
        if (!mongoose.Types.ObjectId.isValid(userId)) {
            return res.status(400).json({ message: 'Invalid user ID format' });
        }

        let bill;
        try {
            bill = await Bill.findOne({
                userId: userId,
                month: monthNum,
                year: yearNum
            });

            console.log('Found bill:', bill);

            if (!bill) {
                return res.status(404).json({ message: 'Bill not found for this user and period' });
            }
        } catch (dbError) {
            console.error('Database error:', dbError);
            return res.status(500).json({ message: 'Database error occurred' });
        }

        // Calculate accurate counts from dailyBreakdown
        let acceptedDays = 0;
        let deniedDays = 0;
        
        if (bill.dailyBreakdown && Array.isArray(bill.dailyBreakdown)) {
            bill.dailyBreakdown.forEach(day => {
                if (day.choice === 'accept') {
                    acceptedDays += 1;
                } else if (day.choice === 'deny') {
                    deniedDays += 1;
                }
            });
        }

        res.json({
            bill: {
                totalAmount: bill.totalAmount,
                acceptedDays: acceptedDays,
                deniedDays: deniedDays,
                dailyBreakdown: bill.dailyBreakdown,
                month: getMonthName(monthNum),
                year: yearNum
            }
        });
    } catch (error) {
        console.error('Get user bill error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Get bookings for a specific date
router.get('/bookings/:date', adminAuth, async (req, res) => {
    try {
        const { date } = req.params;
        // Parse date from params and get bookings for that exact date
        const bookingDate = new Date(date);
        // Find bookings where the 'date' field matches the provided date (ignoring time)
        const startOfDay = new Date(bookingDate);
        startOfDay.setHours(0, 0, 0, 0);
        const endOfDay = new Date(bookingDate);
        endOfDay.setHours(23, 59, 59, 999);
        const bookings = await Booking.find({ date: { $gte: startOfDay, $lte: endOfDay } });
        console.log('bookings', bookings);
        const acceptedCount = bookings.filter(b => b.choice === 'accept').length;
        const deniedCount = bookings.filter(b => b.choice === 'deny').length;

        res.json({
            bookings,
            summary: {
                total: bookings.length,
                accepted: acceptedCount,
                denied: deniedCount
            },
            // date: bookingDate,
            // dayOfWeek: getDayName(bookingDate)
        });
    } catch (error) {
        console.error('Get bookings error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Add new user
router.post('/users', adminAuth, async (req, res) => {
    try {
        const { username, password } = req.body;

        if (!username || !password) {
            return res.status(400).json({ message: 'Username and password are required' });
        }

        const existingUser = await User.findOne({ username });
        if (existingUser) {
            return res.status(400).json({ message: 'User already exists' });
        }

        const user = new User({ username, password });
        await user.save();

        // Generate JWT token for the new user
        const jwt = require('jsonwebtoken');
        const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';
        const tokenPayload = {
            id: user._id,
            username: user.username,
            role: 'user'
        };
        const token = jwt.sign(tokenPayload, JWT_SECRET, { expiresIn: '30d' });

        res.json({
            message: 'User created successfully',
            user: {
                id: user._id,
                username: user.username
            },
            token
        });
    } catch (error) {
        console.error('Create user error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Get all users
router.get('/users', adminAuth, async (req, res) => {
    try {
        const users = await User.find().select('-password').sort({ username: 1 });
        res.json(users);
    } catch (error) {
        console.error('Get users error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Add new admin
router.post('/admins', adminAuth, async (req, res) => {
    try {
        const { username, password } = req.body;

        if (!username || !password) {
            return res.status(400).json({ message: 'Username and password are required' });
        }

        const existingAdmin = await Admin.findOne({ username });
        if (existingAdmin) {
            return res.status(400).json({ message: 'Admin already exists' });
        }

        const admin = new Admin({ username, password });
        await admin.save();

        res.json({
            message: 'Admin created successfully',
            admin: {
                id: admin._id,
                username: admin.username
            }
        });
    } catch (error) {
        console.error('Create admin error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Get all admins
router.get('/admins', adminAuth, async (req, res) => {
    try {
        const admins = await Admin.find().select('-password').sort({ username: 1 });
        res.json(admins);
    } catch (error) {
        console.error('Get admins error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});
 

// Save attendance for a specific date
router.post('/attendance/:date', adminAuth, async (req, res) => {
    try {
        const { date } = req.params;
        const { attendanceData } = req.body;

        if (!attendanceData || !Array.isArray(attendanceData)) {
            return res.status(400).json({ message: 'Attendance data array is required' });
        }

        const bookingDate = new Date(date);
        const startOfDay = new Date(bookingDate);
        startOfDay.setHours(0, 0, 0, 0);
        const endOfDay = new Date(bookingDate);
        endOfDay.setHours(23, 59, 59, 999);
        console.log('attendanceData', attendanceData);

        const Menu = require('../models/Menu');
        const Bill = require('../models/Bill');

        for (const att of attendanceData) {
            // Check if attendance has already been marked for this user on this date
            const existingBooking = await Booking.findOne({ 
                userId: att.userId, 
                date: { $gte: startOfDay, $lte: endOfDay } 
            });

            if (!existingBooking) continue;

            // If attendance has already been marked (present is not null), skip this user
            if (existingBooking.present !== null) {
                console.log(`Skipping ${existingBooking.username} - attendance already marked`);
                continue; // Skip this user but continue with others
            }

            // Update booking present status
            const booking = await Booking.findOneAndUpdate(
                { userId: att.userId, date: { $gte: startOfDay, $lte: endOfDay } },
                { present: att.present },
                { new: true }
            );

            if (!booking) continue;

            // Find or create the user's bill for the month/year
            let bill = await Bill.findOne({ userId: att.userId, month: bookingDate.getMonth(), year: bookingDate.getFullYear() });
            if (!bill) {
                bill = new Bill({
                    userId: att.userId,
                    username: booking.username,
                    month: bookingDate.getMonth(),
                    year: bookingDate.getFullYear(),
                    totalAmount: 0,
                    acceptedDays: 0,
                    deniedDays: 0,
                    dailyBreakdown: []
                });
            }

            // Remove any previous breakdown for this date
            bill.dailyBreakdown = bill.dailyBreakdown.filter(d => {
                const dDate = new Date(d.date);
                return dDate.toDateString() !== bookingDate.toDateString();
            });

            // IMPORTANT: Always preserve the user's original booking choice
            const choice = booking.choice;
            let amount = 0;

            // Get daily cost for this day to calculate amount per person
            const dailyCost = await DailyCost.findOne({ date: { $gte: startOfDay, $lte: endOfDay } });
            
            // If user originally accepted the booking, add daily cost regardless of attendance
            if (choice === 'accept' && dailyCost && dailyCost.costPerPerson > 0) {
                amount = dailyCost.costPerPerson;
                bill.acceptedDays += 1;
                bill.totalAmount += amount;
            } else {
                bill.deniedDays += 1;
            }

            bill.dailyBreakdown.push({
                date: bookingDate,
                dayOfWeek: booking.dayOfWeek,
                choice: choice,
                amount: amount // Always use the calculated amount (0 for denied, daily cost for accepted)
            });

            await bill.save();
        }

        // Count how many users were processed vs skipped
        let processedCount = 0;
        let skippedCount = 0;
        
        for (const att of attendanceData) {
            const existingBooking = await Booking.findOne({ 
                userId: att.userId, 
                date: { $gte: startOfDay, $lte: endOfDay } 
            });
            
            if (existingBooking && existingBooking.present !== null) {
                skippedCount++;
            } else if (existingBooking) {
                processedCount++;
            }
        }
        
        let message = 'Attendance and bills updated successfully';
        if (skippedCount > 0) {
            message += `. ${skippedCount} user(s) skipped (attendance already marked)`;
        }
        
        res.json({ 
            message,
            processed: processedCount,
            skipped: skippedCount
        });
    } catch (error) {
        console.error('Save attendance error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Items List CRUD
router.get('/items', adminAuth, async (req, res) => {
    try {
        const { q } = req.query;
        const filter = q ? { item: { $regex: q, $options: 'i' } } : {};
        const items = await ItemsList.find(filter).sort({ item: 1 });
        res.json({ items });
    } catch (error) {
        console.error('Get items error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Get all items for dropdown (no search filter)
router.get('/items/all', adminAuth, async (req, res) => {
    try {
        const items = await ItemsList.find().sort({ item: 1 });
        res.json({ items });
    } catch (error) {
        console.error('Get all items error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

router.post('/items', adminAuth, async (req, res) => {
    try {
        const { item, range } = req.body;
        if (!item || !range) {
            return res.status(400).json({ message: 'Item and range are required' });
        }
        
        // Validate range format (should contain a hyphen)
        if (!range.includes('-')) {
            return res.status(400).json({ message: 'Range must be in format: min-max (e.g., 500-1000)' });
        }
        
        const existing = await ItemsList.findOne({ item: { $regex: `^${item}$`, $options: 'i' } });
        if (existing) {
            existing.item = item;
            existing.range = range;
            await existing.save();
            return res.json({ message: 'Item updated', item: existing });
        }
        const created = await ItemsList.create({ item, range });
        res.status(201).json({ message: 'Item created', item: created });
    } catch (error) {
        console.error('Create item error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

router.put('/items/:id', adminAuth, async (req, res) => {
    try {
        const { id } = req.params;
        const { item, range } = req.body;
        
        if (!range || !range.includes('-')) {
            return res.status(400).json({ message: 'Range must be in format: min-max (e.g., 500-1000)' });
        }
        
        const updated = await ItemsList.findByIdAndUpdate(
            id,
            { item, range },
            { new: true }
        );
        if (!updated) return res.status(404).json({ message: 'Item not found' });
        res.json({ message: 'Item updated', item: updated });
    } catch (error) {
        console.error('Update item error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

router.delete('/items/:id', adminAuth, async (req, res) => {
    try {
        const { id } = req.params;
        const deleted = await ItemsList.findByIdAndDelete(id);
        if (!deleted) return res.status(404).json({ message: 'Item not found' });
        res.json({ message: 'Item deleted' });
    } catch (error) {
        console.error('Delete item error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});




// Daily Cost Management
router.post('/daily-cost/:date', adminAuth, async (req, res) => {
    try {
        const { date } = req.params;
        const { totalCost } = req.body;

        if (!totalCost || totalCost < 0) {
            return res.status(400).json({ message: 'Valid total cost is required' });
        }

        const costDate = new Date(date);
        const dayOfWeek = getDayName(costDate);
        const weekNumber = getCurrentWeekNumber();
        const month = costDate.getMonth();
        const year = costDate.getFullYear();

        // Validate day is Monday to Friday
        if (!['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'].includes(dayOfWeek)) {
            return res.status(400).json({ message: 'Daily cost can only be set for weekdays' });
        }

        // Count accepted bookings for this day
        const startOfDay = new Date(costDate);
        startOfDay.setHours(0, 0, 0, 0);
        const endOfDay = new Date(costDate);
        endOfDay.setHours(23, 59, 59, 999);
        
        const acceptedBookings = await Booking.countDocuments({
            date: {
                $gte: startOfDay,
                $lte: endOfDay
            },
            choice: 'accept'
        });

        const costPerPerson = acceptedBookings > 0 ? Math.round(totalCost / acceptedBookings) : 0;

        const dailyCostData = {
            date: costDate,
            dayOfWeek,
            totalCost,
            acceptedBookings,
            costPerPerson,
            weekNumber,
            month,
            year
        };

        // Check if daily cost already exists for this date
        // Reuse the startOfDay and endOfDay variables defined above

        const existingDailyCost = await DailyCost.findOne({
            date: { $gte: startOfDay, $lte: endOfDay }
        });

        let dailyCost;
        if (existingDailyCost) {
            dailyCost = await DailyCost.findOneAndUpdate(
                { _id: existingDailyCost._id },
                dailyCostData,
                { new: true }
            );
        } else {
            dailyCost = new DailyCost(dailyCostData);
            await dailyCost.save();
        }

        res.json({
            message: 'Daily cost updated successfully',
            dailyCost
        });
    } catch (error) {
        console.error('Set daily cost error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

router.get('/daily-cost/:date', adminAuth, async (req, res) => {
    try {
        const { date } = req.params;
        const costDate = new Date(date);
        
        const startOfDay = new Date(costDate);
        startOfDay.setHours(0, 0, 0, 0);
        const endOfDay = new Date(costDate);
        endOfDay.setHours(23, 59, 59, 999);

        const dailyCost = await DailyCost.findOne({
            date: { $gte: startOfDay, $lte: endOfDay }
        });

        res.json({ dailyCost });
    } catch (error) {
        console.error('Get daily cost error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Change admin password
router.put('/change-password', adminAuth, async (req, res) => {
    try {
        const { currentPassword, newPassword } = req.body;

        if (!currentPassword || !newPassword) {
            return res.status(400).json({ message: 'Current and new password are required' });
        }

        const admin = await Admin.findById(req.user.id);
        if (!admin) {
            return res.status(404).json({ message: 'Admin not found' });
        }

        const isPasswordValid = await admin.comparePassword(currentPassword);
        if (!isPasswordValid) {
            return res.status(401).json({ message: 'Current password is incorrect' });
        }

        admin.password = newPassword;
        await admin.save();

        res.json({ message: 'Password changed successfully' });
    } catch (error) {
        console.error('Change password error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

module.exports = router;
