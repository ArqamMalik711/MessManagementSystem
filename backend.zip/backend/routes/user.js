const express = require('express');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const Menu = require('../models/Menu');
const Booking = require('../models/Booking');
const Bill = require('../models/Bill');
const DailyCost = require('../models/DailyCost');
const { auth } = require('../middleware/auth');
const { getWeekDates, getDayName, getCurrentWeekNumber, isToday, getMonthName, isDayBookingLocked, canBookToday } = require('../utils/dateUtils');

const router = express.Router();

// Get current week menu for user
router.get('/menu/current-week', auth, async (req, res) => {
    try {
        const weekDates = getWeekDates();
        const currentWeek = getCurrentWeekNumber();
        const currentMonth = new Date().getMonth();
        const currentYear = new Date().getFullYear();

        const menu = await Menu.find({
            weekNumber: currentWeek,
            month: currentMonth,
            year: currentYear
        }).sort({ date: 1 });

        const weekMenu = weekDates.map(date => {
            const dayMenu = menu.find(m => 
                m.date.toDateString() === date.toDateString()
            );
            const isLocked = isDayBookingLocked(date);
            console.log(`Date: ${date.toDateString()}, Day: ${getDayName(date)}, isLocked: ${isLocked}`); // Debug log
            return {
                date: date,
                dayOfWeek: getDayName(date),
                items: dayMenu ? dayMenu.items : [],
                hasMenu: !!dayMenu,
                isToday: isToday(date),
                isLocked: isLocked
            };
        });

        res.json({
            weekMenu,
            currentWeek,
            currentMonth: getMonthName(currentMonth),
            currentYear
        });
    } catch (error) {
        console.error('Get current week menu error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Get today's menu for booking
router.get('/menu/today', auth, async (req, res) => {
    try {
        const today = new Date();
        const dayOfWeek = getDayName(today);
        
        if (!['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'].includes(dayOfWeek)) {
            return res.json({
                hasMenu: false,
                message: 'No menu available for weekends'
            });
        }

        const menu = await Menu.findOne({ date: today });
        
        if (!menu) {
            return res.json({
                hasMenu: false,
                message: 'No menu available for today'
            });
        }

        const existingBooking = await Booking.findOne({
            userId: req.user.id,
            date: today
        });

        res.json({
            hasMenu: true,
            menu: {
                date: today,
                dayOfWeek,
                items: menu.items
            },
            existingBooking: existingBooking ? {
                choice: existingBooking.choice,
                timestamp: existingBooking.createdAt
            } : null
        });
    } catch (error) {
        console.error('Get today menu error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Make booking for today
router.post('/booking/today', auth, async (req, res) => {
    try {
        const { choice } = req.body;
        const today = new Date();
        const dayOfWeek = getDayName(today);

        if (!choice || !['accept', 'deny'].includes(choice)) {
            return res.status(400).json({ message: 'Valid choice (accept/deny) is required' });
        }

        if (!['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'].includes(dayOfWeek)) {
            return res.status(400).json({ message: 'Bookings can only be made for weekdays' });
        }

        const menu = await Menu.findOne({ date: today });
        if (!menu) {
            return res.status(400).json({ message: 'No menu available for today' });
        }

        const existingBooking = await Booking.findOne({
            userId: req.user.id,
            date: today
        });

        if (existingBooking) {
            return res.status(400).json({ message: 'You have already made a booking for today' });
        }

        let totalAmount = 0;
        if (choice === 'accept') {
            // Get daily cost for this day to calculate amount per person
            const dailyCost = await DailyCost.findOne({ date: today });
            if (dailyCost && dailyCost.costPerPerson > 0) {
                totalAmount = dailyCost.costPerPerson;
            }
        }

        const weekNumber = getCurrentWeekNumber();
        const month = today.getMonth();
        const year = today.getFullYear();

        const booking = new Booking({
            userId: req.user.id,
            username: req.user.username,
            date: today,
            dayOfWeek,
            choice,
            weekNumber,
            month,
            year
        });
        await booking.save();

        let bill = await Bill.findOne({ userId: req.user.id, month, year });

        if (!bill) {
            bill = new Bill({
                userId: req.user.id,
                username: req.user.username,
                month,
                year,
                totalAmount: 0,
                acceptedDays: 0,
                deniedDays: 0,
                dailyBreakdown: []
            });
        }

        if (choice === 'accept') {
            bill.acceptedDays += 1;
            bill.totalAmount += totalAmount;
        } else {
            bill.deniedDays += 1;
        }

        bill.dailyBreakdown.push({ date: today, dayOfWeek, choice, amount: totalAmount });
        await bill.save();

        res.json({
            message: 'Booking made successfully',
            booking: { choice, date: today, dayOfWeek, amount: totalAmount }
        });
    } catch (error) {
        console.error('Make booking error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Make booking for the week
router.post('/booking/weekly', auth, async (req, res) => {
    try {
        const { week, menu } = req.body;
        if (!week || !Array.isArray(menu)) {
            return res.status(400).json({ message: 'Week number and menu array are required.' });
        }

        const currentYear = new Date().getFullYear();
        const currentMonth = new Date().getMonth();

        let createdBookings = [];
        let updatedBookings = [];
        let updatedBill = await Bill.findOne({ userId: req.user.id, month: currentMonth, year: currentYear });

        if (!updatedBill) {
            updatedBill = new Bill({
                userId: req.user.id,
                username: req.user.username,
                month: currentMonth,
                year: currentYear,
                totalAmount: 0,
                acceptedDays: 0,
                deniedDays: 0,
                dailyBreakdown: []
            });
        }

        // Get existing bookings for this week to handle updates
        const existingWeekBookings = await Booking.find({ 
            userId: req.user.id, 
            weekNumber: week,
            month: currentMonth,
            year: currentYear
        });

        // Create a map of existing bookings by date for easy lookup
        const existingBookingsMap = {};
        existingWeekBookings.forEach(booking => {
            existingBookingsMap[booking.date.toDateString()] = booking;
        });

        for (const day of menu) {
            const date = new Date(day.date);
            const dayOfWeek = getDayName(date);

            // Check if this day's booking is locked
            if (isDayBookingLocked(date)) {
                return res.status(400).json({ 
                    message: `Booking for ${dayOfWeek} is locked. Previous days and today after 10 AM cannot be booked.` 
                });
            }

            const existingBooking = existingBookingsMap[date.toDateString()];
            let totalAmount = 0;
            
            if (day.choice === 'accept') {
                // Get daily cost for this day to calculate amount per person
                const dailyCost = await DailyCost.findOne({ date });
                if (dailyCost && dailyCost.costPerPerson > 0) {
                    totalAmount = dailyCost.costPerPerson;
                }
            }

            if (existingBooking) {
                // Update existing booking
                const oldChoice = existingBooking.choice;
                existingBooking.choice = day.choice;
                await existingBooking.save();
                updatedBookings.push(existingBooking);

                // Update bill based on choice change
                if (oldChoice === 'accept' && day.choice === 'deny') {
                    // Changed from accept to deny - reduce bill
                    updatedBill.acceptedDays -= 1;
                    updatedBill.deniedDays += 1;
                    // Find and remove the old amount from dailyBreakdown
                    const breakdownIndex = updatedBill.dailyBreakdown.findIndex(
                        d => d.date.toDateString() === date.toDateString()
                    );
                    if (breakdownIndex !== -1) {
                        updatedBill.totalAmount -= updatedBill.dailyBreakdown[breakdownIndex].amount;
                        updatedBill.dailyBreakdown[breakdownIndex] = { 
                            date, 
                            dayOfWeek, 
                            choice: day.choice, 
                            amount: 0 
                        };
                    }
                } else if (oldChoice === 'deny' && day.choice === 'accept') {
                    // Changed from deny to accept - increase bill
                    updatedBill.acceptedDays += 1;
                    updatedBill.deniedDays -= 1;
                    updatedBill.totalAmount += totalAmount;
                    // Update the dailyBreakdown
                    const breakdownIndex = updatedBill.dailyBreakdown.findIndex(
                        d => d.date.toDateString() === date.toDateString()
                    );
                    if (breakdownIndex !== -1) {
                        updatedBill.dailyBreakdown[breakdownIndex] = { 
                            date, 
                            dayOfWeek, 
                            choice: day.choice, 
                            amount: totalAmount 
                        };
                    }
                }
                // If choice didn't change, no bill update needed
            } else {
                // Create new booking
                const booking = new Booking({
                    userId: req.user.id,
                    username: req.user.username,
                    date,
                    dayOfWeek,
                    choice: day.choice,
                    weekNumber: week,
                    month: currentMonth,
                    year: currentYear
                });
                await booking.save();
                createdBookings.push(booking);

                // Update bill for new booking
                if (day.choice === 'accept') {
                    updatedBill.acceptedDays += 1;
                    updatedBill.totalAmount += totalAmount;
                } else {
                    updatedBill.deniedDays += 1;
                }

                updatedBill.dailyBreakdown.push({ date, dayOfWeek, choice: day.choice, amount: totalAmount });
            }
        }

        await updatedBill.save();

        res.status(201).json({
            message: 'Weekly bookings updated successfully',
            createdBookings,
            updatedBookings
        });
    } catch (error) {
        console.error('Weekly booking error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Get user's current month bill
router.get('/bill/current-month', auth, async (req, res) => {
    try {
        const currentMonth = new Date().getMonth();
        const currentYear = new Date().getFullYear();

        const bill = await Bill.findOne({
            userId: req.user.id,
            month: currentMonth,
            year: currentYear
        });

        if (!bill) {
            return res.json({
                hasBill: false,
                message: 'No bill available for current month'
            });
        }

        // Calculate accurate counts from dailyBreakdown
        let acceptedDays = 0;
        let deniedDays = 0;
        
        if (bill.dailyBreakdown && Array.isArray(bill.dailyBreakdown)) {
            bill.dailyBreakdown.forEach(day => {
                if (day.choice === 'accept') {
                    acceptedDays += 1;
                } else if (day.choice === 'deny') {
                    deniedDays += 1;
                }
            });
        }

        res.json({
            hasBill: true,
            bill: {
                totalAmount: bill.totalAmount,
                acceptedDays: acceptedDays,
                deniedDays: deniedDays,
                dailyBreakdown: bill.dailyBreakdown,
                month: getMonthName(currentMonth),
                year: currentYear
            }
        });
    } catch (error) {
        console.error('Get current month bill error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Change user password
router.put('/change-password', auth, async (req, res) => {
    try {
        const { currentPassword, newPassword } = req.body;

        if (!currentPassword || !newPassword) {
            return res.status(400).json({ message: 'Current and new password are required' });
        }

        const user = await User.findById(req.user.id);
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        const isPasswordValid = await user.comparePassword(currentPassword);
        if (!isPasswordValid) {
            return res.status(401).json({ message: 'Current password is incorrect' });
        }

        user.password = newPassword;
        await user.save();

        res.json({ message: 'Password changed successfully' });
    } catch (error) {
        console.error('Change password error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Get user's booking history
router.get('/bookings/history', auth, async (req, res) => {
    try {
        const { month, year } = req.query;
        const query = { userId: req.user.id };

        if (month && year) {
            query.month = parseInt(month);
            query.year = parseInt(year);
        }

        const bookings = await Booking.find(query)
            .sort({ date: -1 })
            .limit(50);

        res.json({ bookings });
    } catch (error) {
        console.error('Get booking history error:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

module.exports = router;
