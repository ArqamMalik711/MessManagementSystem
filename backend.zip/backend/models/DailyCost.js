const mongoose = require('mongoose');

const dailyCostSchema = new mongoose.Schema({
    date: {
        type: Date,
        required: true,
        unique: true
    },
    dayOfWeek: {
        type: String,
        required: true,
        enum: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']
    },
    totalCost: {
        type: Number,
        required: true,
        min: 0
    },
    acceptedBookings: {
        type: Number,
        default: 0
    },
    costPerPerson: {
        type: Number,
        default: 0
    },
    weekNumber: {
        type: Number,
        required: true
    },
    month: {
        type: Number,
        required: true
    },
    year: {
        type: Number,
        required: true
    }
}, {
    timestamps: true
});

// Compound index for efficient querying
dailyCostSchema.index({ weekNumber: 1, month: 1, year: 1 });
dailyCostSchema.index({ date: 1 });

module.exports = mongoose.model('DailyCost', dailyCostSchema);
