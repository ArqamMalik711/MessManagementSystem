const mongoose = require('mongoose');

const menuItemSchema = new mongoose.Schema({
    item: {
        type: String,
        required: true,
        trim: true
    },
    range: {
        type: String,
        required: true,
        trim: true
    }
});

const menuSchema = new mongoose.Schema({
    date: {
        type: Date,
        required: true,
        unique: true
    },
    dayOfWeek: {
        type: String,
        required: true,
        enum: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']
    },
    items: [menuItemSchema],
    weekNumber: {
        type: Number,
        required: true
    },
    month: {
        type: Number,
        required: true
    },
    year: {
        type: Number,
        required: true
    }
}, {
    timestamps: true
});

// Compound index for efficient querying by week
menuSchema.index({ weekNumber: 1, month: 1, year: 1 });

module.exports = mongoose.model('Menu', menuSchema); 