const mongoose = require('mongoose');

const billSchema = new mongoose.Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    username: {
        type: String,
        required: true
    },
    month: {
        type: Number,
        required: true
    },
    year: {
        type: Number,
        required: true
    },
    totalAmount: {
        type: Number,
        default: 0,
        min: 0
    },
    acceptedDays: {
        type: Number,
        default: 0
    },
    deniedDays: {
        type: Number,
        default: 0
    },
    dailyBreakdown: [{
        date: {
            type: Date,
            required: true
        },
        dayOfWeek: {
            type: String,
            required: true
        },
        choice: {
            type: String,
            required: true,
            enum: ['accept', 'deny']
        },
        amount: {
            type: Number,
            default: 0
        }
    }]
}, {
    timestamps: true
});

// Compound index for efficient querying
billSchema.index({ userId: 1, month: 1, year: 1 }, { unique: true });

module.exports = mongoose.model('Bill', billSchema); 