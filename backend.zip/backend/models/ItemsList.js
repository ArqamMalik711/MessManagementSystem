const mongoose = require('mongoose');

const ItemsListSchema = new mongoose.Schema(
	{
		item: { type: String, required: true, trim: true },
		range: { type: String, required: true, trim: true }
	},
	{
		timestamps: true,
		collection: 'itemslist'
	}
);

ItemsListSchema.index({ item: 'text' });

module.exports = mongoose.model('ItemsList', ItemsListSchema);


