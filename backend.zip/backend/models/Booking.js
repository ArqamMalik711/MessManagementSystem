const mongoose = require('mongoose');

const bookingSchema = new mongoose.Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    username: {
        type: String,
        required: true
    },
    date: {
        type: Date,
        required: true
    },
    dayOfWeek: {
        type: String,
        required: true,
        enum: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']
    },
    choice: {
        type: String,
        required: true,
        enum: ['accept', 'deny']
    },
    weekNumber: {
        type: Number,
        required: true
    },
    month: {
        type: Number,
        required: true
    },
    year: {
        type: Number,
        required: true
    },
    present: {
        type: Boolean,
        default: null
    },
    submittedAt: {
        type: Date,
        default: Date.now
    }
}, {
    timestamps: true
});

// Compound index for efficient querying
bookingSchema.index({ date: 1, userId: 1 }, { unique: true });
bookingSchema.index({ weekNumber: 1, month: 1, year: 1 });

module.exports = mongoose.model('Booking', bookingSchema); 