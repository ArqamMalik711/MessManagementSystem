# Mess Management System - Backend

This is the backend API for the Mess Management System.

## Setup

1. Install dependencies:
```bash
npm install
```

2. Make sure MongoDB is running on localhost:27017

3. Create a `.env` file in the backend directory with:
```
PORT=5000
JWT_SECRET=your-super-secret-jwt-key-change-this-in-production
MONGODB_URI=mongodb://localhost:27017/messdb
```

4. Start the server:
```bash
npm run dev
```

## API Endpoints

### Authentication

#### User Login
- **POST** `/api/auth/user/login`
- **Body:** `{ "username": "string", "password": "string" }`
- **Response:** JWT token and user data

#### Admin Login
- **POST** `/api/auth/admin/login`
- **Body:** `{ "username": "string", "password": "string" }`
- **Response:** JWT token and admin data

#### Get Current User
- **GET** `/api/auth/user/me`
- **Headers:** `Authorization: Bearer <token>`
- **Response:** Current user data

#### Get Current Admin
- **GET** `/api/auth/admin/me`
- **Headers:** `Authorization: Bearer <token>`
- **Response:** Current admin data

### Admin Routes (Protected)

#### Menu Management
- **GET** `/api/admin/menu/current-week` - Get current week menu
- **POST** `/api/admin/menu/:date` - Create/Update menu for specific date
- **DELETE** `/api/admin/menu/:date` - Delete menu for specific date

#### Bill Management
- **GET** `/api/admin/bills/:month/:year` - Get all bills for a month

#### Booking Management
- **GET** `/api/admin/bookings/:date` - Get bookings for specific date
- **Query:** `?search=username` - Search users in bookings

#### User Management
- **GET** `/api/admin/users` - Get all users
- **POST** `/api/admin/users` - Add new user
- **Body:** `{ "username": "string", "password": "string" }`

#### Admin Management
- **GET** `/api/admin/admins` - Get all admins
- **POST** `/api/admin/admins` - Add new admin
- **Body:** `{ "username": "string", "password": "string" }`

#### Password Management
- **PUT** `/api/admin/change-password` - Change admin password
- **Body:** `{ "currentPassword": "string", "newPassword": "string" }`

### User Routes (Protected)

#### Menu & Booking
- **GET** `/api/user/menu/current-week` - Get current week menu
- **GET** `/api/user/menu/today` - Get today's menu for booking
- **POST** `/api/user/booking/today` - Make booking for today
- **Body:** `{ "choice": "accept" | "deny" }`

#### Bill Management
- **GET** `/api/user/bill/current-month` - Get current month bill
- **GET** `/api/user/bookings/history` - Get booking history
- **Query:** `?month=number&year=number` - Filter by month/year

#### Password Management
- **PUT** `/api/user/change-password` - Change user password
- **Body:** `{ "currentPassword": "string", "newPassword": "string" }`

## Database Collections

- **users**: User accounts (username, password)
- **admins**: Admin accounts (username, password)
- **menus**: Weekly menu items with prices
- **bookings**: User food choices for each day
- **bills**: Monthly bills for each user

## Features

- JWT-based authentication
- Password hashing with bcrypt
- Role-based access control
- MongoDB integration
- CORS enabled for frontend integration
- Weekly menu management (Monday-Friday)
- Real-time bill calculation
- User booking system
- Admin dashboard with comprehensive management tools 