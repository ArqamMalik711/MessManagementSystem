// Get current week number (Monday to Friday)
function getCurrentWeekNumber() {
    const now = new Date();
    const startOfYear = new Date(now.getFullYear(), 0, 1);
    const days = Math.floor((now - startOfYear) / (24 * 60 * 60 * 1000));
    return Math.ceil((days + startOfYear.getDay() + 1) / 7);
}

// Get week dates (Monday to Friday) for a given date
function getWeekDates(date = new Date()) {
    const current = new Date(date);
    const week = [];
    const day = current.getDay();
    const diff = current.getDate() - day + (day === 0 ? -6 : 1); // Adjust when day is Sunday
    
    for (let i = 0; i < 5; i++) {
        const weekDay = new Date(current.setDate(diff + i));
        week.push(new Date(weekDay));
    }
    
    return week;
}

// Get day name from date
function getDayName(date) {
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    return days[date.getDay()];
}

// Check if date is today
function isToday(date) {
    const today = new Date();
    return date.getDate() === today.getDate() &&
           date.getMonth() === today.getMonth() &&
           date.getFullYear() === today.getFullYear();
}

// Check if it's Monday
function isMonday(date = new Date()) {
    return getDayName(date) === 'Monday';
}

// Check if current time allows weekly submissions (Monday only, before 11:59 PM)
function canSubmitWeeklyChoices() {
    const now = new Date();
    return isMonday(now);
}

// Check if a specific day's booking is locked
function isDayBookingLocked(date) {
    const now = new Date();
    const targetDate = new Date(date);
    
    // Reset time to start of day for accurate comparison
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    targetDate.setHours(0, 0, 0, 0);
    
    console.log(`Debug - Target date: ${targetDate.toDateString()}, Today: ${today.toDateString()}, Current hour: ${now.getHours()}`); // Debug log
    
    // Previous days are always locked
    if (targetDate < today) {
        console.log(`Day ${targetDate.toDateString()} is locked (previous day)`); // Debug log
        return true;
    }
    
    // Today's booking is locked after 10 AM
    if (targetDate.getTime() === today.getTime()) {
        const currentHour = now.getHours();
        const isLocked = currentHour >= 10;
        console.log(`Today ${targetDate.toDateString()} is ${isLocked ? 'locked' : 'unlocked'} (hour: ${currentHour})`); // Debug log
        return isLocked;
    }
    
    // Future days are not locked
    console.log(`Day ${targetDate.toDateString()} is unlocked (future day)`); // Debug log
    return false;
}

// Check if current time allows today's booking
function canBookToday() {
    const now = new Date();
    const currentHour = now.getHours();
    return currentHour < 10;
}

// Get month name
function getMonthName(month) {
    const months = [
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December'
    ];
    return months[month];
}

// Format date for display
function formatDate(date) {
    return date.toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

module.exports = {
    getCurrentWeekNumber,
    getWeekDates,
    getDayName,
    isToday,
    isMonday,
    canSubmitWeeklyChoices,
    isDayBookingLocked,
    canBookToday,
    getMonthName,
    formatDate
}; 